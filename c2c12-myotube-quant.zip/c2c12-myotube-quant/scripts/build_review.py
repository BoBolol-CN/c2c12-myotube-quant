from pathlib import Path
import argparse,json,hashlib,shutil,math
from PIL import Image,ImageDraw,ImageFont
p=argparse.ArgumentParser(description='Build mandatory, local number-only MyHC review HTML without measuring images')
p.add_argument('--run-root',type=Path,required=True);p.add_argument('--preview-dir',type=Path,required=True);p.add_argument('--myhc-multiplier',type=float);a=p.parse_args()
root=a.run_root.resolve();out=a.preview_dir.resolve()
if out.parent!=root:raise ValueError('preview-dir must be a direct child of run-root')
source=out/'preview_manifest.json'
if not source.exists():source=out/'pilot_previews.json'
data=json.loads(source.read_text(encoding='utf-8-sig'))
if not data.get('complete'):raise ValueError('Complete native ImageJ preview first')
if not data.get('round') and data.get('design') and len(data['fields'])!=sum(g['field_count'] for g in data['design']['groups']):raise ValueError('The mandatory first-round HTML must include all expected fields, not only the five-field pilot')
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
try:font=ImageFont.truetype('arial.ttf',22)
except OSError:font=ImageFont.load_default()
fields=[]
for i,r in enumerate(data['fields'],1):
 n=r.get('index',i);mult=r.get('current_myhc_multiplier',r.get('myhc_multiplier',data.get('settings',{}).get('myhc_multiplier',a.myhc_multiplier)))
 if not isinstance(mult,(int,float)) or not math.isfinite(mult) or mult<=0:raise ValueError('Explicit MyHC multiplier needed for '+r['field'])
 prov=r.get('myhc_provenance',r.get('channel_provenance',{}).get('myhc',{}));mask=prov.get('mask_path',r.get('provenance',{}).get('myhc_mask_path'))
 if not mask:raise ValueError('Missing native MyHC mask path')
 folder=Path(mask).parent;dest=out/f'field_{n:04d}'/'myhc';dest.mkdir(parents=True,exist_ok=True)
 for name in ['pure_channel.png','contours.png','mask.png']:
  src=folder/name
  if src.resolve()!=(dest/name).resolve():shutil.copy2(src,dest/name)
 prov=dict(prov,mask_path=str(dest/'mask.png'),mask_sha256=sha(dest/'mask.png'))
 row=dict(r,index=n,current_myhc_multiplier=mult,previous_myhc_multiplier=r.get('previous_myhc_multiplier',mult),myhc_provenance=prov)
 fields.append(row)
 pair=Image.new('RGB',(1400,625),'#202020');draw=ImageDraw.Draw(pair)
 draw.text((10,10),f'#{n:02d} | {r["group"]} | {r["field"]} | MyHC x{mult}',font=font,fill='white')
 for j,name in enumerate(['pure_channel.png','contours.png']):
  im=Image.open(dest/name).convert('RGB');im.thumbnail((690,553),Image.Resampling.LANCZOS);pair.paste(im,(j*700,60))
 pair.save(out/f'{n:02d}_myhc_review.jpg',quality=95)
if source.name=='preview_manifest.json' and not (out/'preview_manifest_before_html.json').exists():shutil.copy2(source,out/'preview_manifest_before_html.json')
round_number=data.get('round',1);data.update(fields=fields,round=round_number,round_key=data.get('round_key','round'+str(round_number)+'-'+sha(source)[:12]),accepted_count=data.get('accepted_count',0))
(out/'preview_manifest.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8')
asset=Path(__file__).resolve().parent.parent/'assets/review.html';page=asset.read_text(encoding='utf8');groups=list(dict.fromkeys(r['group'] for r in fields));page=page.replace('<option>1-4</option><option>1-5</option><option>1-6</option>',''.join('<option>'+g+'</option>' for g in groups));(out/'review.html').write_text(page,encoding='utf8')
(root/'active_review_round.json').write_text(json.dumps(dict(folder=out.name,round=round_number,round_key=data['round_key']),indent=2),encoding='utf8')
print('HTML ready: '+str(out/'review.html')+'; serve with review_server.py --run-root '+str(root))
