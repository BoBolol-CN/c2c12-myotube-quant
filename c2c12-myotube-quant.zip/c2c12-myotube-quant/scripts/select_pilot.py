"""Select up to five different fields, prioritizing different confirmed groups."""
import argparse
import json
import random
import secrets
from pathlib import Path
from validate_manifest import read_json, sha256, validate_manifest


def select(fields, seed):
    groups = {}
    for row in fields:
        groups.setdefault(row['group'], []).append(row)
    rng = random.Random(seed)
    names = rng.sample(list(groups), min(5, len(groups)))
    selected = [rng.choice(groups[name]) for name in names]
    remaining = [r for r in fields if r not in selected]
    selected += rng.sample(remaining, min(5, len(fields)) - len(selected))
    return selected


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--manifest', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--seed', type=int)
    a = p.parse_args()
    data = validate_manifest(read_json(a.manifest))
    seed = a.seed if a.seed is not None else secrets.randbits(32)
    payload = dict(batch_id=data['batch_id'], manifest_sha256=sha256(a.manifest), random_seed=seed,
                   fields=select(data['fields'], seed), available_fields=len(data['fields']),
                   available_groups=len(data['design']['groups']), user_approved=False)
    a.out.parent.mkdir(parents=True, exist_ok=True)
    with a.out.open('x', encoding='utf8') as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    print('Pilot selected; awaiting both channel reviews')
