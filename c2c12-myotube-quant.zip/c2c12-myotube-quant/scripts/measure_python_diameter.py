"""Python diameter only; native ImageJ remains responsible for area, nuclei and fusion."""
from pathlib import Path
import numpy as np
import scipy, skimage, tifffile
from PIL import Image
from skimage.measure import regionprops
from skimage.morphology import skeletonize
from scipy.ndimage import distance_transform_edt

METHOD = 'Python scikit-image skeletonize + SciPy exact Euclidean distance transform; zero-padded native 8-connected objects; mean 2r per object, equal object weights per field'

def measure_diameter(mask_path, native_labels_path, native_objects, out):
    m = np.asarray(Image.open(mask_path)) > 0
    raw_labels = tifffile.imread(native_labels_path)
    if raw_labels.shape != m.shape or not np.all(np.isfinite(raw_labels)) or not np.all(raw_labels == np.floor(raw_labels)):
        raise ValueError('Invalid native object labels')
    labels = raw_labels.astype(np.int32)
    if np.any(labels < 0) or not np.array_equal(labels > 0, m):
        raise ValueError('Native labels do not describe the accepted MyHC mask')
    expected = {int(o['object_id']): o for o in native_objects}
    props = regionprops(labels)
    if set(expected) != {o.label for o in props}:
        raise ValueError('Python/native object IDs differ')
    skeleton_map = np.zeros(m.shape, dtype=bool)
    diameter_map = np.zeros(m.shape, dtype=np.float32)
    rows = []
    for obj in props:
        if int(obj.area) != expected[obj.label]['area_px2']:
            raise ValueError('Python/native object extent differs')
        crop = np.pad(obj.image, 1)
        skeleton = skeletonize(crop)
        if not skeleton.any():
            raise ValueError('Object has no skeleton')
        local_diameter = 2 * distance_transform_edt(crop)
        mean = float(local_diameter[skeleton].mean())
        rows.append(dict(object_id=int(obj.label), diameter_px=mean, skeleton_pixels=int(skeleton.sum())))
        y0,x0,y1,x1 = obj.bbox
        core = skeleton[1:-1,1:-1]
        skeleton_map[y0:y1,x0:x1] |= core
        diameter_map[y0:y1,x0:x1][core] = local_diameter[1:-1,1:-1][core]
    if not rows:
        raise ValueError('Empty MyHC mask')
    out = Path(out); out.mkdir(parents=True,exist_ok=True)
    tifffile.imwrite(out/'python_skeleton.tif',skeleton_map.astype('uint8')*255,compression='deflate',metadata=None)
    tifffile.imwrite(out/'python_diameters_on_skeleton32.tif',diameter_map,compression='deflate',metadata=None)
    values = [o['diameter_px'] for o in rows]
    return dict(summary={'diameter_mean_px':float(np.mean(values)), 'diameter_median_px':float(np.median(values))},objects=rows,method=METHOD,versions={'scipy':scipy.__version__,'scikit_image':skimage.__version__,'numpy':np.__version__})
