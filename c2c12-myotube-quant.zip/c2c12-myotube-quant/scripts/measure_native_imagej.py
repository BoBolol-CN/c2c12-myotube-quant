"""Compatibility entry point. Current workflow uses native ImageJ area/fusion and Python diameter."""
from measure_reviewed_masks import main
if __name__ == '__main__':
    main()
