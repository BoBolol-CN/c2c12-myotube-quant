import fs from 'node:fs/promises';
import path from 'node:path';
import {Workbook, SpreadsheetFile} from '@oai/artifact-tool';

const args=process.argv.slice(2), option=(name)=>args[args.indexOf(name)+1];
if(!args.includes('--input')||!args.includes('--output'))throw Error('Provide --input batch_measurements.json --output result.xlsx');
const input=path.resolve(option('--input')), output=path.resolve(option('--output'));
if(path.extname(output).toLowerCase()!=='.xlsx')throw Error('Final output must be .xlsx');
const data=JSON.parse(await fs.readFile(input,'utf8'));
if(data.version!==2||data.mode!=='measure'||data.complete!==true)throw Error('Only a complete measured batch can be exported');
const design=data.design;
if(!(design?.user_confirmed===true&&design?.mapping_confirmed===true&&design?.user_response?.trim()&&typeof design.biological_replicates_are_wells==='boolean'))throw Error('Ask user for confirmed field counts, well counts and mapping first');
const rows=data.fields, manifestRows=data.input_manifest?.fields;
if(!rows?.length||!manifestRows||manifestRows.length!==rows.length)throw Error('Missing expected fields');
if(data.settings?.min_nuclei_for_fusion!==2)throw Error('Fusion must use >=2-nucleus objects');
const key=(r)=>JSON.stringify([r.group,r.field]);
const expected=new Map(manifestRows.map(r=>[key(r),r]));
if(expected.size!==rows.length||new Set(rows.map(key)).size!==rows.length)throw Error('Duplicate fields');
for(const row of rows){
 const origin=expected.get(key(row));
 if(!origin||origin.well!==row.well||origin.myhc!==row.myhc||origin.dapi!==row.dapi)throw Error('Field/well mapping differs from confirmed manifest');
 if(row.issues?.length)throw Error('Review unresolved field issues before export: '+row.field);
 const s=row.summary;
 for(const k of ['field_area_px2','myhc_area_px2','myhc_area_fraction','diameter_mean_px','diameter_median_px','n_nuclei_total','n_nuclei_in_myhc','n_nuclei_single_objects','n_fusion_nuclei_ge2','fusion_fraction','n_objects','n_objects_ge2','n_objects_zero'])if(typeof s?.[k]!=='number'||!Number.isFinite(s[k]))throw Error('Missing metric '+row.field+' '+k);
 if(s.n_nuclei_total<=0||s.n_objects<=0)throw Error('Empty masks require review');
 if(Math.abs(s.fusion_fraction-s.n_fusion_nuclei_ge2/s.n_nuclei_total)>1e-12||s.n_fusion_nuclei_ge2!==s.n_nuclei_in_myhc-s.n_nuclei_single_objects)throw Error('Fusion does not reconcile');
 if(Math.abs(s.myhc_area_fraction-s.myhc_area_px2/s.field_area_px2)>1e-12)throw Error('Area does not reconcile');
 if(row.objects.reduce((n,o)=>n+o.area_px2,0)!==s.myhc_area_px2||row.objects.reduce((n,o)=>n+(o.n_nuclei>=2?o.n_nuclei:0),0)!==s.n_fusion_nuclei_ge2)throw Error('Object details do not reconcile');
 if(row.nuclei.length!==s.n_nuclei_total||row.nuclei.filter(n=>n.eligible).length!==s.n_fusion_nuclei_ge2)throw Error('Nucleus details do not reconcile');
}
const groups=design.groups.map(g=>g.name);
if(!groups.length||new Set(groups).size!==groups.length||new Set(rows.map(r=>r.group)).size!==groups.length||rows.some(r=>!groups.includes(r.group)))throw Error('Group list does not match fields');
const wells=new Map();
for(const g of design.groups){
 const selected=rows.filter(r=>r.group===g.name), names=[...new Set(selected.map(r=>r.well))];
 if(!Number.isInteger(g.field_count)||!Number.isInteger(g.well_count)||g.field_count!==selected.length||g.well_count!==names.length||names.length===0)throw Error('User-confirmed field/well count mismatch: '+g.name);
 wells.set(g.name,names);
}
const wb=Workbook.create(), sh=wb.worksheets.add('视野与Prism');
const navy='#233B53', ink='#23313D', last=rows.length+1;
const letters=(i)=>{let s='';for(i++;i>0;i=Math.floor((i-1)/26))s=String.fromCharCode(65+(i-1)%26)+s;return s;};
const finalCol=letters(20+groups.length-1);
const maxWells=Math.max(...[...wells.values()].map(x=>x.length));
const bottom=Math.max(last+12,4*(maxWells+3)+6);
sh.showGridLines=false;sh.tabColor=navy;
sh.getRange(`A1:${finalCol}${bottom}`).format.font={name:'Arial',size:11,color:ink};
sh.getRange(`A1:${finalCol}${bottom}`).format.verticalAlignment='center';
const header=(range)=>{sh.getRange(range).format={fill:navy,font:{name:'Arial',size:11,bold:true,color:'#FFFFFF'},horizontalAlignment:'center',verticalAlignment:'center',wrapText:true,borders:{insideVertical:{style:'thin',color:'#FFFFFF'}}};};
const headers=['序号','样本/组','MyHC视野','DAPI视野','视野面积（px²）','阳性面积（px²）','阳性面积（%）','MyHC对象数','直径均值（px）','直径中位数（px）','总DAPI核数','MyHC内核数','单核对象内核数','≥2核对象内核数','融合指数（%）','≥2核对象数','无核对象数','孔号','孔内视野序号'];
sh.getRange('A1:S1').values=[headers];header('A1:S1');
const keys=['field_area_px2','myhc_area_px2','myhc_area_fraction','n_objects','diameter_mean_px','diameter_median_px','n_nuclei_total','n_nuclei_in_myhc','n_nuclei_single_objects','n_fusion_nuclei_ge2','fusion_fraction','n_objects_ge2','n_objects_zero'];
const counters=new Map();
const matrix=rows.map((r,i)=>{
 const k=JSON.stringify([r.group,r.well]), seq=(counters.get(k)||0)+1;counters.set(k,seq);
 return [i+1,r.group,r.field,path.parse(path.win32.basename(r.dapi)).name,...keys.map(k=>r.summary[k]),r.well,seq];
});
sh.getRange(`A2:S${last}`).values=matrix;
for(const [c,w] of Object.entries({A:8,B:16,C:20,D:20,E:21,F:21,G:19,H:17,I:19,J:21,K:17,L:19,M:23,N:25,O:19,P:20,Q:19,R:16,S:19,T:36}))sh.getRange(`${c}:${c}`).format.columnWidth=w;
for(let i=0;i<groups.length;i++){const c=letters(20+i);sh.getRange(`${c}:${c}`).format.columnWidth=21;}
sh.getRange(`A1:${finalCol}1`).format.rowHeight=45;
sh.getRange(`A2:S${last}`).format.rowHeight=27;
sh.tables.add(`A1:S${last}`,true,'FieldResults');
for(const c of ['E','F','H','K','L','M','N','P','Q','S'])sh.getRange(`${c}2:${c}${last}`).setNumberFormat('#,##0');
for(const c of ['G','O'])sh.getRange(`${c}2:${c}${last}`).setNumberFormat('0.000%');
sh.getRange(`I2:J${last}`).setNumberFormat('0.000');

const metrics=[
 {label:'融合指数（%）',col:'O',key:'fusion_fraction',scale:100},
 {label:'MyHC阳性面积比例（%）',col:'G',key:'myhc_area_fraction',scale:100},
 {label:'肌管直径均值（px）',col:'I',key:'diameter_mean_px',scale:1},
 {label:'MyHC阳性面积（px²）',col:'F',key:'myhc_area_px2',scale:1},
];
const checks=[], ranges=[];
for(let mi=0;mi<metrics.length;mi++){
 const m=metrics[mi], start=1+mi*(maxWells+3);
 sh.getRange(`T${start}`).values=[[m.label]];
 sh.getRange(`T${start}`).format.font={name:'Arial',size:11,bold:true,color:navy};
 sh.getRange(`U${start}:${finalCol}${start}`).values=[groups];header(`U${start}:${finalCol}${start}`);
 sh.getRange(`T${start}:${finalCol}${start}`).format.rowHeight=32;
 for(let wi=0;wi<maxWells;wi++){
  const r=start+wi+1, label=design.biological_replicates_are_wells?'生物学重复':'孔';
  sh.getRange(`T${r}`).values=[[`${label}${wi+1}（各组孔标签见下方）`]];
  sh.getRange(`T${r}:${finalCol}${r}`).format.rowHeight=28;
  if(wi%2===0)sh.getRange(`U${r}:${finalCol}${r}`).format.fill='#EAF1F7';
  for(let gi=0;gi<groups.length;gi++){
   const group=groups[gi],well=wells.get(group)[wi];if(well===undefined)continue;
   const selected=rows.map((x,i)=>({x,i})).filter(({x})=>x.group===group&&x.well===well);
   const indices=selected.map(({i})=>i+2), contiguous=indices.every((v,i)=>i===0||v===indices[i-1]+1);
   const ref=contiguous?`${m.col}${indices[0]}:${m.col}${indices.at(-1)}`:indices.map(i=>`${m.col}${i}`).join(',');
   const cell=`${letters(20+gi)}${r}`,formula=`=AVERAGE(${ref})${m.scale===100?'*100':''}`;
   sh.getRange(cell).formulas=[[formula]];
   checks.push({cell,group,well,metric:m.label,fields:selected.map(({x})=>x.field),formula,expected:selected.reduce((a,{x})=>a+x.summary[m.key],0)/selected.length*m.scale});
  }
 }
 sh.getRange(`U${start+1}:${finalCol}${start+maxWells}`).setNumberFormat(m.key==='myhc_area_px2'?'#,##0.000':'0.000');
 ranges.push(`U${start}:${finalCol}${start+maxWells}`);
}
const annotation=1+4*(maxWells+3);
sh.getRange(`T${annotation}`).values=[['各组实际孔标签（顺序对应上方各表）']];
sh.getRange(`U${annotation}:${finalCol}${annotation}`).values=[groups];header(`U${annotation}:${finalCol}${annotation}`);
for(let wi=0;wi<maxWells;wi++)sh.getRange(`U${annotation+wi+1}:${finalCol}${annotation+wi+1}`).values=[groups.map(g=>wells.get(g)[wi]??null)];
const noteStart=last+3;
const notes=[
 `每组视野与孔数：${design.groups.map(g=>`${g.name}：${g.field_count}个视野、${g.well_count}个孔`).join('；')}。`,
 '每孔数值为该孔全部已确认视野结果的算术平均；融合指数先逐视野计算再取平均。',
 design.biological_replicates_are_wells?'使用者确认每孔为一个生物学重复；n为每组孔数，视野为孔内子样本。':'使用者未将孔定义为生物学重复；此表仅给出孔均值，不自行声明生物学n。',
 `右侧Prism Column复制范围（含样本名）：${ranges.join('；')}。`,
 '右侧百分比使用0–100数值；直径单位px、绝对面积单位px²，无有效长度校准。',
 `本批MyHC乘数${data.settings.myhc_multiplier}、DAPI乘数${data.settings.dapi_multiplier}；不是跨批固定参数。`,
 '融合指数只计含≥2个核的MyHC对象内核数；面积与直径仍包括单核和无核对象。',
 ...(data.exclusions||[]).map(r=>`不纳入计算：${r.group} ${r.well} ${r.field}，${r.reason}；原文件保留。`),
 '每孔仅平均实际纳入的视野；保留1个时直接取该视野值，保留0个时该孔不可用，不记0。',
 `测量来源：用户已验收的MyHC/DAPI掩膜；${data.settings.measurement_engine || '详见本批测量记录'}。`,
];
sh.getRange(`A${noteStart}:A${noteStart+notes.length-1}`).values=notes.map(x=>[x]);
sh.getRange(`A${noteStart}:S${noteStart+notes.length-1}`).format.rowHeight=25;
sh.getRange(`A${noteStart}:S${noteStart+notes.length-1}`).format.font={name:'Arial',size:11,color:'#566575'};
sh.freezePanes.unfreeze();
wb.recalculate();
for(const check of checks){const value=sh.getRange(check.cell).values[0][0];if(typeof value!=='number'||Math.abs(value-check.expected)>1e-10*Math.max(1,Math.abs(check.expected)))throw Error('Incorrect well mean '+check.cell);check.actual=value;}
const errors=await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!',options:{useRegex:true,maxResults:20},maxChars:2000});
const outDir=path.dirname(output);await fs.mkdir(outDir,{recursive:true});
await fs.writeFile(path.join(outDir,'excel_formula_scan.ndjson'),errors.ndjson);
await fs.writeFile(path.join(outDir,'excel_mean_verification.json'),JSON.stringify({fields:rows.length,groups:design.groups,copyRanges:ranges,checks},null,2));
for(const [range,name] of [[`T1:${finalCol}${annotation+maxWells}`,'preview_prism.png'],[`A1:J${Math.min(last,10)}`,'preview_fields_left.png'],[`K1:S${Math.min(last,19)}`,'preview_fields_right.png']]){
 const image=await wb.render({sheetName:sh.name,range,scale:1.3,format:'png'});await fs.writeFile(path.join(outDir,name),new Uint8Array(await image.arrayBuffer()));
}
const result=await SpreadsheetFile.exportXlsx(wb);await result.save(output);
console.log(JSON.stringify({output,fields:rows.length,wellMeans:checks.length,copyRanges:ranges,frozenPanes:false}));
