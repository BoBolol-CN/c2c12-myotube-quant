import fs from 'node:fs/promises';
import path from 'node:path';
import {Workbook, SpreadsheetFile} from '@oai/artifact-tool';

const args=process.argv.slice(2), option=(name)=>args[args.indexOf(name)+1];
if(!args.includes('--input')||!args.includes('--output'))throw Error('Provide --input batch_measurements.json --output result.xlsx');
const input=path.resolve(option('--input')), output=path.resolve(option('--output'));
if(path.extname(output).toLowerCase()!=='.xlsx')throw Error('Final output must be .xlsx');
const data=JSON.parse(await fs.readFile(input,'utf8'));
if(data.version!==2||data.mode!=='measure'||data.complete!==true)throw Error('Only a complete measured batch can be exported');
const design=data.design;
if(!(design?.user_confirmed===true&&design?.mapping_confirmed===true&&design?.user_response?.trim()&&typeof design.biological_replicates_are_wells==='boolean'))throw Error('Ask user for confirmed field counts, well counts and mapping first');
const rows=data.fields, manifestRows=data.input_manifest?.fields;
if(!rows?.length||!manifestRows||manifestRows.length!==rows.length)throw Error('Missing expected fields');
if(data.settings?.min_nuclei_for_fusion!==2)throw Error('Fusion must use >=2-nucleus objects');
const key=(r)=>JSON.stringify([r.group,r.field]);
const expected=new Map(manifestRows.map(r=>[key(r),r]));
if(expected.size!==rows.length||new Set(rows.map(key)).size!==rows.length)throw Error('Duplicate fields');
for(const row of rows){
 const origin=expected.get(key(row));
 if(!origin||origin.well!==row.well||origin.myhc!==row.myhc||origin.dapi!==row.dapi)throw Error('Field/well mapping differs from confirmed manifest');
 if(row.issues?.length)throw Error('Review unresolved field issues before export: '+row.field);
 const s=row.summary;
 for(const k of ['field_area_px2','myhc_area_px2','myhc_area_fraction','diameter_mean_px','diameter_median_px','n_nuclei_total','n_nuclei_in_myhc','n_nuclei_single_objects','n_fusion_nuclei_ge2','fusion_fraction','n_objects','n_objects_ge2','n_objects_zero'])if(typeof s?.[k]!=='number'||!Number.isFinite(s[k]))throw Error('Missing metric '+row.field+' '+k);
 if(s.n_nuclei_total<=0||s.n_objects<=0)throw Error('Empty masks require review');
 if(Math.abs(s.fusion_fraction-s.n_fusion_nuclei_ge2/s.n_nuclei_total)>1e-12||s.n_fusion_nuclei_ge2!==s.n_nuclei_in_myhc-s.n_nuclei_single_objects)throw Error('Fusion does not reconcile');
 if(Math.abs(s.myhc_area_fraction-s.myhc_area_px2/s.field_area_px2)>1e-12)throw Error('Area does not reconcile');
 if(row.objects.reduce((n,o)=>n+o.area_px2,0)!==s.myhc_area_px2||row.objects.reduce((n,o)=>n+(o.n_nuclei>=2?o.n_nuclei:0),0)!==s.n_fusion_nuclei_ge2)throw Error('Object details do not reconcile');
 if(row.nuclei.length!==s.n_nuclei_total||row.nuclei.filter(n=>n.eligible).length!==s.n_fusion_nuclei_ge2)throw Error('Nucleus details do not reconcile');
}
const groups=design.groups.map(g=>g.name);
if(!groups.length||new Set(groups).size!==groups.length||new Set(rows.map(r=>r.group)).size!==groups.length||rows.some(r=>!groups.includes(r.group)))throw Error('Group list does not match fields');
const wells=new Map();
for(const g of design.groups){
 const selected=rows.filter(r=>r.group===g.name), names=[...new Set(selected.map(r=>r.well))];
 if(!Number.isInteger(g.field_count)||!Number.isInteger(g.well_count)||g.field_count!==selected.length||g.well_count!==names.length||names.length===0)throw Error('User-confirmed field/well count mismatch: '+g.name);
 wells.set(g.name,names);
}

const letters=(i)=>{let s='';for(i++;i>0;i=Math.floor((i-1)/26))s=String.fromCharCode(65+(i-1)%26)+s;return s;};
const planRows=[...manifestRows,...(data.exclusions||[])];
const layout=[];
for(const group of groups){
 const planned=planRows.filter(r=>r.group===group);
 const names=[...new Set(planned.map(r=>r.well))].sort((a,b)=>a.localeCompare(b,undefined,{numeric:true}));
 const orig=data.input_manifest.original_design?.groups?.find(g=>g.name===group);
 if(orig&&(orig.field_count!==planned.length||orig.well_count!==names.length))throw Error('Original slot mapping incomplete: '+group);
 for(const well of names)layout.push({group,well,slots:planned.filter(r=>r.well===well).length});
}
const ids=rows.map(r=>r.field);if(new Set(ids).size!==ids.length)throw Error('MyHC identifiers must be unique across this workbook');
const keys=['field_area_px2','myhc_area_px2','myhc_area_fraction','n_objects','diameter_mean_px','diameter_median_px','n_nuclei_total','n_nuclei_in_myhc','n_nuclei_single_objects','n_fusion_nuclei_ge2','fusion_fraction','n_objects_ge2','n_objects_zero'];
const source={headers:['序号','样本/组','MyHC视野','DAPI视野','视野面积（px²）','阳性面积（px²）','阳性面积比例','MyHC对象数','直径均值（px）','直径中位数（px）','总DAPI核数','MyHC内核数','单核对象内核数','≥2核对象内核数','融合比例','≥2核对象数','无核对象数','原孔号','原孔内序号'],data:rows.map((r,i)=>[i+1,r.group,r.field,path.parse(path.win32.basename(r.dapi)).name,...keys.map(k=>r.summary[k]),r.well,rows.slice(0,i+1).filter(x=>x.group===r.group&&x.well===r.well).length]),params:[['组别','原孔号','视野','MyHC乘数','DAPI方法','纳入计算','说明','MyHC审阅快照','DAPI审阅快照'],...planRows.map(r=>[r.group,r.well,r.field,r.myhc_multiplier??null,r.dapi_method??r.dapi_multiplier??null,expected.has(key(r))?'是':'否',r.reason||'',r.review_snapshot||'',r.dapi_review_snapshot||''])]};
const last=rows.length+1;
const wb=Workbook.create();
const assign=wb.worksheets.add('视野安排');
const summary=wb.worksheets.add('Prism汇总');
const raw=wb.worksheets.add('原始视野数据');
const params=wb.worksheets.add('参数与排除');
raw.getRange(`A1:S${last}`).values=[source.headers,...source.data];
params.getRange(`A1:I${source.params.length}`).values=source.params;
assign.getRange('A1:H1').values=[['固定组别','固定孔位','MyHC视野编号（可移动）','DAPI视野','融合指数（%）','MyHC面积（%）','直径（px）','核对状态']];
const slots=[], blocks=[];
for (const group of groups) {
 const plan=layout.filter(p=>p.group===group);
 for(const p of plan) {
  const list=source.data.filter(r=>r[1]===group&&r[17]===p.well);
  const start=slots.length+2;
  for(let k=0;k<p.slots;k++)slots.push([group,p.well,list[k]?.[2]??null,null,null,null,null,null]);
  blocks.push({group,well:p.well,start,end:slots.length+1,list});
 }
}
const slotLast=slots.length+1;
assign.getRange(`A2:H${slotLast}`).values=slots;
let ff=[];
for(let r=2;r<=slotLast;r++) {
 const id='INDIRECT("C"&ROW())';
 const lookup=(col)=>`IFERROR(INDEX('原始视野数据'!$${col}$2:$${col}${last},MATCH(${id},'原始视野数据'!$C$2:$C${last},0)),"")`;
 const f=(col,mul='')=>`=IF(${id}="","",IFERROR(INDEX('原始视野数据'!$${col}$2:$${col}${last},MATCH(${id},'原始视野数据'!$C$2:$C${last},0))${mul},""))`;
 ff.push([f('D'),f('O','*100'),f('G','*100'),f('I'),`=IF(${id}="","",IF(COUNTIF('原始视野数据'!$C$2:$C${last},${id})<>1,"异常：编号不存在",IF(COUNTIF($C$2:$C${slotLast},${id})>1,"异常：编号重复",IF(${lookup('B')}<>A${r},"异常：组别不符","正常"))))`]);
}
assign.getRange(`D2:H${slotLast}`).formulas=ff;
assign.getRange('I1').values=[['MyHC面积（px²）']];
assign.getRange(`I2:I${slotLast}`).formulas=Array.from({length:slots.length},()=>[`=IF(INDIRECT("C"&ROW())="","",IFERROR(INDEX('原始视野数据'!$F$2:$F$${last},MATCH(INDIRECT("C"&ROW()),'原始视野数据'!$C$2:$C$${last},0)),""))`]);
assign.getRange(`A${slotLast+3}`).values=[['使用：固定组别和孔位不移动；只调整C列视野编号。每孔按确认设计预留位置，空白不计入。']];
assign.getRange(`A${slotLast+4}`).values=[['交换两个编号时，可先将其中一个编号暂存到J2，再粘贴另一个编号，最后将暂存编号粘回。']];
assign.getRange(`A${slotLast+5}`).values=[['调整后检查H列状态；编号重复、查无记录或组别不符时，该孔汇总留空。']];
assign.getRange(`A${slotLast+6}`).values=[['本表只包含已纳入的视野；排除记录与原文件保留在“参数与排除”。']];
assign.getRange('J1').values=[['交换时暂存区']];
const cols=groups.map((_,i)=>letters(i+1));const finalCol=cols.at(-1);const maxWells=Math.max(...groups.map(g=>layout.filter(p=>p.group===g).length));const checks=[];const countHead=4*(maxWells+3)+1;
for (const [head,metric,label] of [[1,'E','融合指数（%）'],[maxWells+4,'F','MyHC阳性面积比例（%）'],[2*(maxWells+3)+1,'G','肌管直径均值（px）'],[3*(maxWells+3)+1,'I','MyHC阳性面积（px²）']]){
 summary.getRange(`A${head}`).values=[[label]];
 summary.getRange(`B${head}:${finalCol}${head}`).values=[groups];
 for(let h=1;h<=maxWells;h++) {
  summary.getRange(`A${head+h}`).values=[[`孔${h}`]];
  for(let g=0;g<groups.length;g++) {
   const block=blocks.filter(b=>b.group===groups[g])[h-1];if(!block)continue;const {start:st,end:en}=block;
   summary.getRange(`${cols[g]}${head+h}`).formulas=[[`=IF(COUNTIF('视野安排'!$H$${st}:$H$${en},"异常：编号不存在")+COUNTIF('视野安排'!$H$${st}:$H$${en},"异常：编号重复")+COUNTIF('视野安排'!$H$${st}:$H$${en},"异常：组别不符")>0,"",IF(COUNT('视野安排'!$${metric}$${st}:$${metric}$${en})=0,"",AVERAGE('视野安排'!$${metric}$${st}:$${metric}$${en})))`]];
  }
 }
}
summary.getRange(`A${countHead}:${finalCol}${countHead}`).values=[['每孔有效视野数',...groups]];
for(let h=1;h<=maxWells;h++){
 summary.getRange(`A${countHead+h}`).values=[[`孔${h}`]];
 for(let g=0;g<groups.length;g++){
 const block=blocks.filter(b=>b.group===groups[g])[h-1];if(!block)continue;const {start:st,end:en}=block;
 summary.getRange(`${cols[g]}${countHead+h}`).formulas=[[`=COUNT('视野安排'!$E$${st}:$E$${en})`]];
 }
}
summary.getRange(`A${countHead+maxWells+3}`).values=[['复制各组标题及其孔值到Prism；重复单位见确认设计。']];
summary.getRange(`A${countHead+maxWells+4}`).values=[['空白表示无有效视野或该孔编号有异常；请检查“视野安排”的核对状态。']];
summary.getRange(`A${countHead+maxWells+5}`).values=[['百分比为0–100；直径为px。改变视野安排后，已有Prism文件需重新复制数据。']];
for(const s of [assign,summary,raw,params]) {s.getRange('A1:U1').format.font={name:'Arial',bold:true,color:'#FFFFFF'};s.getRange('A1:U1').format.fill='#243A50';}
for(const r of [maxWells+4,2*(maxWells+3)+1,3*(maxWells+3)+1,countHead]){summary.getRange(`A${r}:${finalCol}${r}`).format.font={name:'Arial',bold:true,color:'#FFFFFF'};summary.getRange(`A${r}:${finalCol}${r}`).format.fill='#243A50';}
assign.getRange('A:A').format.columnWidth=13;assign.getRange('B:B').format.columnWidth=11;assign.getRange('C:C').format.columnWidth=28;assign.getRange('D:D').format.columnWidth=21;assign.getRange('E:G').format.columnWidth=18;assign.getRange('H:H').format.columnWidth=23;assign.getRange('I:I').format.columnWidth=20;assign.getRange('J:J').format.columnWidth=23;
assign.getRange(`C2:C${slotLast}`).format.fill='#FFF2CC';assign.getRange(`A2:B${slotLast}`).format.fill='#E7EEF5';assign.getRange('J2').format.fill='#FFF2CC';assign.getRange(`E2:G${slotLast}`).setNumberFormat('0.000');
summary.getRange('A:A').format.columnWidth=28;summary.getRange(`B:${finalCol}`).format.columnWidth=14;summary.getRange(`B2:${finalCol}${countHead+maxWells}`).setNumberFormat('0.000');summary.getRange(`B${countHead+1}:${finalCol}${countHead+maxWells}`).setNumberFormat('0');
raw.getRange('A:S').format.columnWidth=18;params.getRange('A:I').format.columnWidth=18;
wb.recalculate();

for(const [head,key,scale] of [[1,'fusion_fraction',100],[maxWells+4,'myhc_area_fraction',100],[2*(maxWells+3)+1,'diameter_mean_px',1],[3*(maxWells+3)+1,'myhc_area_px2',1]])for(const b of blocks){
 const wi=layout.filter(p=>p.group===b.group).findIndex(p=>p.well===b.well),gi=groups.indexOf(b.group),cell=cols[gi]+(head+wi+1);
 const actual=summary.getRange(cell).values[0][0];const selected=rows.filter(r=>r.group===b.group&&r.well===b.well);
 const expected=selected.length?selected.reduce((s,r)=>s+r.summary[key]*scale,0)/selected.length:'';
 if(expected===''?actual!=='':typeof actual!=='number'||Math.abs(actual-expected)>1e-8)throw Error('Mean mismatch '+cell);
 checks.push({cell,group:b.group,well:b.well,key,expected,actual});
}
await fs.mkdir(path.dirname(output),{recursive:true});
await fs.writeFile(path.join(path.dirname(output),'excel_mean_verification.json'),JSON.stringify({layout,checks},null,2));
let out=await SpreadsheetFile.exportXlsx(wb);await out.save(output);
for(const name of ['视野安排','Prism汇总']){
 const preview=await wb.render({sheetName:name,range:name==='视野安排'?'A1:J15':`A1:${finalCol}${countHead+maxWells}`,scale:1,format:'png'});
 await fs.writeFile(path.join(path.dirname(output),`slot_${name}.png`),new Uint8Array(await preview.arrayBuffer()));
}

console.log(JSON.stringify({output,groups:groups.length,fields:rows.length,slots:slots.length,sheets:[assign.name,summary.name,raw.name,params.name]}));
