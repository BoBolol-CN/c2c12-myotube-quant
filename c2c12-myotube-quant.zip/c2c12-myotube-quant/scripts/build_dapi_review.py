"""Build the required DAPI HTML review stage after all selected MyHC masks pass."""
from pathlib import Path
import argparse,json,hashlib,shutil,subprocess,sys
from PIL import Image,ImageDraw,ImageFont
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--run-root',type=Path,required=True);p.add_argument('--out-name',default='dapi_review_round_01');p.add_argument('--default-multiplier',type=float,required=True);a=p.parse_args()
root=a.run_root.resolve();ledger=json.loads((root/'batch_review_ledger.json').read_text('utf-8'))
selected=[r for r in ledger['fields'] if r.get('review_status')!='excluded']
if not selected or any(r.get('review_status')!='accepted' for r in selected):raise ValueError('Complete MyHC review before opening DAPI review')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
out=root/a.out_name
if out.parent!=root:raise ValueError('Output must be a direct child of run-root')
out.mkdir();rows=[]
font=ImageFont.truetype('C:/Windows/Fonts/msyh.ttc',22)
for r in selected:
 prov=r['dapi_provenance'];assert sha(prov['mask_path'])==prov['mask_sha256']
 n=r['index'];dest=out/f'field_{n:04d}'/'dapi';dest.mkdir(parents=True)
 for name in ['pure_channel.png','contours.png','mask.png']:shutil.copy2(Path(prov['mask_path']).parent/name,dest/name)
 pair=Image.new('RGB',(1400,625),'#202020');draw=ImageDraw.Draw(pair);draw.text((10,10),f"#{n:02d} | {r['group']} | {Path(r['dapi']).stem} | DAPI",font=font,fill='white')
 for j,name in enumerate(['pure_channel.png','contours.png']):
  im=Image.open(dest/name).convert('RGB');im.thumbnail((690,553),Image.Resampling.LANCZOS);pair.paste(im,(j*700,60))
 pair.save(out/f'{n:02d}_dapi_review.jpg',quality=95)
 mult=r.get('current_dapi_multiplier',r.get('dapi_multiplier',a.default_multiplier))
 rows.append(dict(r,current_dapi_multiplier=mult,previous_dapi_multiplier=mult,dapi_provenance=dict(prov,mask_path=str(dest/'mask.png'),mask_sha256=sha(dest/'mask.png'))))
manifest=dict(batch_id=ledger['batch_id'],manifest_sha256=sha(root/'input.json'),round=1,round_key='dapi-round1-'+sha(root/'batch_review_ledger.json')[:12],accepted_count=0,complete=True,channel='dapi',fields=rows,myhc_stage_complete=True)
(out/'preview_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),'utf-8')
skill=Path(__file__).resolve().parent.parent
html=(skill/'assets/review.html').read_text('utf-8').replace('MyHC','DAPI').replace('myhc','dapi')
groups=list(dict.fromkeys(r['group'] for r in rows));html=html.replace('<option>1-4</option><option>1-5</option><option>1-6</option>',''.join('<option>'+g+'</option>' for g in groups))
html=html.replace('只填写还需要更改的DAPI乘数。','MyHC已确认，现在逐张确认DAPI核轮廓。只填写还需要更改的DAPI乘数。')
html=html.replace('${r.field}','${r.dapi_field}（配对${r.field}）')
(out/'review.html').write_text(html,'utf-8')
(root/'active_dapi_review_round.json').write_text(json.dumps(dict(folder=out.name,round=1,round_key=manifest['round_key']),indent=2),'utf-8')
print('DAPI HTML ready. Start review_server.py --channel dapi --run-root '+str(root)+' --port 8769')
