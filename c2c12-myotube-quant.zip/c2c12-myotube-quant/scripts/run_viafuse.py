"""Native ImageJ ViaFuse segmentation. Defaults to contour preview only."""
from pathlib import Path
import shutil,subprocess
import numpy as np,tifffile
from PIL import Image,ImageDraw
from skimage.measure import find_contours
SKILL=Path(__file__).resolve().parent.parent

def display(raw,mask,channel,out):
    lo,hi=np.percentile(raw,[1,99 if channel==1 else 99.5])
    base=np.clip((raw.astype(np.float32)-lo)/max(float(hi-lo),1),0,1)
    rgb=np.zeros((*raw.shape,3),dtype=np.uint8)
    rgb[...,channel]=np.rint(np.clip((np.sqrt(base)-.1)*1.2+.1,0,1)*255).astype(np.uint8)
    im=Image.fromarray(rgb);im.save(out/'pure_channel.png');draw=ImageDraw.Draw(im)
    for contour in find_contours(np.pad(mask,1),.5):draw.line([(float(x-1),float(y-1)) for y,x in contour],fill=(255,255,0),width=2)
    im.save(out/'contours.png')

def run_channel(path,channel,multiplier,block,out,imagej,temp):
    out.mkdir(parents=True,exist_ok=True)
    raw=tifffile.imread(path)
    if raw.ndim==3 and raw.shape[-1]==3:raw=raw[...,channel]
    if raw.ndim!=2 or raw.dtype!=np.uint16:raise ValueError('Expected a uint16 2D channel or RGB TIFF')
    working=out/'original_channel16.tif';tifffile.imwrite(working,raw,photometric='minisblack',metadata=None)
    native_input=temp/f'channel{channel}.tif';shutil.copy2(working,native_input)
    if not np.array_equal(raw,tifffile.imread(native_input)):raise ValueError('Lossless channel copy check failed')
    native_output=temp/f'mask{channel}.tif';macro_path=temp/f'run{channel}.ijm'
    header='''print("NATIVE_IMAGEJ_VERSION="+getVersion());
arg=getArgument();separator=indexOf(arg,"|");
input=substring(arg,0,separator);out=substring(arg,separator+1);
open(input);rename("MyHC");myh="MyHC";
'''
    setup=f'multip={multiplier};\n'
    if channel==1:setup+=f'run("Multiply...", "value={multiplier:g}");\n'
    macro=header+setup+block+'\nrun("Grays");\nsaveAs("Tiff",out);\nclose();eval("script","System.exit(0);");\n'
    macro_path.write_text(macro,encoding='ascii');(out/'executed_macro.ijm').write_text(macro,encoding='utf-8')
    command=[str(imagej),'--headless','--ij1','--no-splash','--console','--memory','2g','-macro',str(macro_path),native_input.as_posix()+'|'+native_output.as_posix()]
    with (out/'imagej_console.log').open('w',encoding='utf-8') as f:
        proc=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,timeout=180)
    if proc.returncode or not native_output.exists():raise RuntimeError('ImageJ failed; see '+str(out/'imagej_console.log'))
    shutil.copy2(native_output,out/'imagej_binary.tif')
    binary=tifffile.imread(native_output)>0
    Image.fromarray(binary.astype(np.uint8)*255).save(out/'mask.png')
    display(raw,binary,channel,out)
    return binary

if __name__=='__main__':
    raise SystemExit('Use run_batch.py for preview or reviewed measurement with confirmed well design.')
