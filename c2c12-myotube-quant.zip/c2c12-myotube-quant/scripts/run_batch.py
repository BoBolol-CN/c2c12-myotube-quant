"""Run a reviewed ViaFuse batch with explicit field/well design; JSON intermediate for Excel."""
import argparse
import json
import math
import shutil
import tempfile
from pathlib import Path
from validate_manifest import read_json, sha256, validate_manifest, validate_review
from run_viafuse import run_channel, SKILL
from measure_masks import measure


def author_blocks():
    f = (SKILL / 'assets/viafuse/ViaFuse_F_windows.ijm').read_text(encoding='utf8')
    v = (SKILL / 'assets/viafuse/ViaFuse_V_windows.ijm').read_text(encoding='utf8')
    myhc = f[f.index('selectWindow(myh);', f.index('run("Watershed");')):f.index('//image subtraction')]
    # The author's second conversion must retain 255 foreground explicitly;
    # re-auto-thresholding a binary image can reverse the selected class.
    myhc = myhc.replace('//setThreshold(255, 255);', 'setThreshold(255, 255);')
    return myhc, v[v.index('run("Multiply...", "value=multip");'):v.index('run("Set Measurements..."')]



def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--manifest', type=Path, required=True)
    p.add_argument('--pilot', type=Path, help='Legacy compatibility only; no pilot sampling is used')
    p.add_argument('--review-record', type=Path)
    p.add_argument('--mode', choices=['preview', 'measure'], default='preview')
    p.add_argument('--all-fields', action='store_true', default=True, help='Legacy compatibility flag; preview always includes all fields')
    p.add_argument('--myhc-multiplier', type=float, required=True)
    p.add_argument('--dapi-multiplier', type=float, required=True)
    p.add_argument('--imagej', type=Path, default=Path('E:/Study program/Fiji.app/ImageJ-win64.exe'))
    p.add_argument('--accepted-masks', type=Path)
    p.add_argument('--temp-root', type=Path, default=Path('E:/codex/_temp/viafuse'), help='ASCII working directory on E drive')
    p.add_argument('--out', type=Path, required=True)
    a = p.parse_args()
    if a.mode == 'measure':
        p.error('Use measure_reviewed_masks.py after HTML review: ImageJ area/fusion and Python diameter')
    manifest = validate_manifest(read_json(a.manifest))
    # First-round preview always includes all fields; legacy pilot files do not select a subset.
    pilot_keys = []
    if not all(math.isfinite(x) and x > 0 for x in [a.myhc_multiplier, a.dapi_multiplier]):
        raise ValueError('Multipliers must be finite and positive')
    if a.mode == 'measure':
        if not a.review_record:
            raise ValueError('Measurement requires both channel reviews')
        validate_review(read_json(a.review_record), manifest, a.manifest, pilot_keys, a.myhc_multiplier, a.dapi_multiplier)
    elif a.accepted_masks:
        raise ValueError('Accepted-mask reuse is only for reviewed measurement mode')
    accepted = None
    if a.accepted_masks:
        cache = read_json(a.accepted_masks)
        for key, expected in [('batch_id', manifest['batch_id']), ('manifest_sha256', sha256(a.manifest)),
                              ('myhc_multiplier', a.myhc_multiplier), ('dapi_multiplier', a.dapi_multiplier)]:
            if cache.get(key) != expected:
                raise ValueError('Accepted masks do not match approved batch: ' + key)
        accepted = {(r['group'], r['field']): r for r in cache['fields']}
        if len(accepted) != len(cache['fields']) or set(accepted) != {(r['group'], r['field']) for r in manifest['fields']}:
            raise ValueError('Accepted masks must cover the exact manifest without duplicates')
        for row in accepted.values():
            for role in ['myhc', 'dapi']:
                if sha256(row[role + '_mask']) != row[role + '_mask_sha256']:
                    raise ValueError('Accepted mask checksum mismatch')
    if accepted is None and not a.imagej.is_file():
        raise FileNotFoundError(a.imagej)
    if a.out.exists():
        raise FileExistsError('Use a new output directory to preserve prior results')
    a.out.mkdir(parents=True)
    blocks = author_blocks()
    selected = manifest['fields']
    payload = dict(version=2, batch_id=manifest['batch_id'], mode=a.mode, complete=False,
                   design=manifest['design'], input_manifest=manifest, manifest_sha256=sha256(a.manifest),
                   settings=dict(myhc_multiplier=a.myhc_multiplier, dapi_multiplier=a.dapi_multiplier,
                                 min_nuclei_for_fusion=2, extra_filter=False, manual_correction=False,
                                 imagej=str(a.imagej), calibration=None), fields=[])
    destination = a.out / ('batch_measurements.json' if a.mode == 'measure' else 'pilot_previews.json')
    for i, row in enumerate(selected, 1):
        target = a.out / f'field_{i:04d}'
        target.mkdir()
        source_hashes = {role: sha256(row[role]) for role in ['myhc', 'dapi']}
        print(f"{a.mode.upper()} {i}/{len(selected)} {row['group']} {row['field']}", flush=True)
        if accepted is not None:
            cache = accepted[(row['group'], row['field'])]
            for role in ['myhc', 'dapi']:
                d = target / role
                d.mkdir()
                shutil.copy2(cache[role + '_mask'], d / 'mask.png')
            origin = 'reused exact user-approved ViaFuse masks with checksum verification'
        else:
            a.temp_root.mkdir(parents=True, exist_ok=True)
            with tempfile.TemporaryDirectory(prefix='viafuse_', dir=a.temp_root) as td:
                if not td.isascii():
                    raise ValueError('ImageJ requires an ASCII TEMP/TMP directory')
                run_channel(Path(row['myhc']), 1, a.myhc_multiplier, blocks[0], target / 'myhc', a.imagej, Path(td))
                run_channel(Path(row['dapi']), 2, a.dapi_multiplier, blocks[1], target / 'dapi', a.imagej, Path(td))
            origin = 'native ImageJ launcher; author ViaFuse channel segmentation blocks'
        if any(sha256(row[role]) != source_hashes[role] for role in ['myhc', 'dapi']):
            raise RuntimeError('Source image changed during processing')
        result = dict(group=row['group'], well=row['well'], field=row['field'], myhc=row['myhc'], dapi=row['dapi'])
        if a.mode == 'measure':
            result.update(measure(target / 'myhc/mask.png', target / 'dapi/mask.png', target))
        else:
            result['provenance'] = {role + '_mask_path': str((target / role / 'mask.png').resolve()) for role in ['myhc', 'dapi']}
        result['provenance'].update(original_sources_sha256=source_hashes, origin=origin)
        payload['fields'].append(result)
        destination.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf8')
        if result.get('issues'):
            raise RuntimeError('Field requires review; batch aggregation stopped: ' + ', '.join(result['issues']))
    payload['complete'] = True
    destination.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf8')
    print('Complete: ' + str(destination), flush=True)


if __name__ == '__main__':
    main()
