"""Measure exact accepted ViaFuse masks; fusion numerator excludes single-nucleus objects."""
import json
from pathlib import Path
import numpy as np
from PIL import Image
from scipy import ndimage as ndi
from skimage.measure import label, regionprops
from skimage.morphology import skeletonize
from validate_manifest import sha256


def measure(myhc_path, dapi_path, out):
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    m = np.asarray(Image.open(myhc_path)) > 0
    n = np.asarray(Image.open(dapi_path)) > 0
    if m.ndim != 2 or m.shape != n.shape:
        raise ValueError('Expected matching 2D white-foreground masks')
    ml, nl = label(m, connectivity=2), label(n, connectivity=2)
    props = regionprops(ml)
    counts = np.zeros(len(props) + 1, dtype=np.int64)
    nuclei, objects, diameters = [], [], []
    for obj in regionprops(nl):
        y, x = obj.centroid
        iy = min(m.shape[0] - 1, int(np.floor(y + .5)))
        ix = min(m.shape[1] - 1, int(np.floor(x + .5)))
        oid = int(ml[iy, ix])
        counts[oid] += 1
        nuclei.append(dict(nucleus_id=int(obj.label), x=float(x), y=float(y), myhc_object_id=oid))
    for obj in props:
        crop = np.pad(obj.image, 1)
        skeleton = skeletonize(crop)
        diameter = float((2 * ndi.distance_transform_edt(crop)[skeleton]).mean()) if skeleton.any() else None
        if diameter is not None:
            diameters.append(diameter)
        k = int(counts[obj.label])
        objects.append(dict(object_id=int(obj.label), area_px2=int(obj.area), diameter_px=diameter,
                            skeleton_pixels=int(skeleton.sum()), n_nuclei=k, eligible=k >= 2))
    for row in nuclei:
        oid = row['myhc_object_id']
        row['eligible'] = bool(oid and counts[oid] >= 2)
        row['assignment'] = 'outside' if not oid else ('single_nucleus_excluded' if counts[oid] == 1 else 'ge2_nuclei_included')
    total, inside = len(nuclei), int(counts[1:].sum())
    single = int(np.sum(counts[1:] == 1))
    fusion = sum(r['n_nuclei'] for r in objects if r['eligible'])
    if not (inside - single == fusion == sum(r['eligible'] for r in nuclei)):
        raise RuntimeError('Fusion numerator does not reconcile')
    if int(m.sum()) != sum(r['area_px2'] for r in objects):
        raise RuntimeError('Area does not reconcile')
    summary = dict(field_area_px2=int(m.size), myhc_area_px2=int(m.sum()), myhc_area_fraction=float(m.mean()),
                   n_objects=len(props), diameter_mean_px=float(np.mean(diameters)) if diameters else None,
                   diameter_median_px=float(np.median(diameters)) if diameters else None,
                   n_nuclei_total=total, n_nuclei_in_myhc=inside, n_nuclei_single_objects=single,
                   n_fusion_nuclei_ge2=fusion, fusion_fraction=fusion / total if total else None,
                   n_objects_ge2=sum(r['eligible'] for r in objects), n_objects_zero=int(np.sum(counts[1:] == 0)))
    provenance = dict(myhc_mask_path=str(Path(myhc_path).resolve()), dapi_mask_path=str(Path(dapi_path).resolve()),
                      myhc_mask_sha256=sha256(myhc_path), dapi_mask_sha256=sha256(dapi_path),
                      fusion_definition='nuclei assigned by centroid to MyHC objects with >=2 nuclei / all DAPI nuclei',
                      diameter_method='padded object crop skeleton + 2*EDT; equal object weights',
                      mask_contract='same MyHC mask for area, diameter and nucleus assignment; no filtering',
                      units={'diameter': 'px', 'area': 'px2'}, manual_correction=False)
    issues = []
    if total == 0:
        issues.append('zero_dapi_nuclei')
    if not props:
        issues.append('empty_myhc_mask')
    payload = dict(summary=summary, objects=objects, nuclei=nuclei, provenance=provenance, issues=issues)
    for filename, value in [('measurement.json', payload), ('field_summary.json', summary),
                            ('myhc_objects.json', objects), ('nucleus_assignments.json', nuclei)]:
        (out / filename).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf8')
    return payload


if __name__ == '__main__':
    raise SystemExit('Use run_batch.py to validate the user-confirmed well design and both channel reviews before measurement.')
