"""Approved LoG-v1 DAPI instance segmentation; no per-image user review required."""
from pathlib import Path
import json,hashlib
import numpy as np,tifffile,scipy,skimage
from scipy import ndimage as ndi
from skimage.feature import blob_log
from skimage.filters import threshold_otsu
from skimage.morphology import remove_small_holes,remove_small_objects
from skimage.segmentation import watershed,relabel_sequential,find_boundaries
from skimage.measure import regionprops
from PIL import Image
METHOD_ID='python_dapi_log_v1'
PARAMETERS=dict(analysis_downsample=2,background_gaussian_sigma_half_px=25,normalization_percentile=99.8,smoothing_sigma_half_px=.7,log_min_sigma_half_px=3,log_max_sigma_half_px=10,log_scales=10,log_threshold=.05,log_overlap=.5,foreground_otsu_factor=.5,minimum_foreground_area_half_px2=25,fill_holes_area_half_px2=16,minimum_instance_area_half_px2=25,watershed_connectivity=2,include_border=True)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def segment(raw):
 if raw.ndim!=2 or raw.dtype!=np.uint16:raise ValueError('Expected original uint16 DAPI blue channel')
 small=ndi.zoom(raw.astype('float32'),.5,order=1)
 corrected=np.maximum(small-ndi.gaussian_filter(small,25),0)
 hi=float(np.percentile(corrected,99.8));norm=np.clip(corrected/max(hi,1),0,1);smooth=ndi.gaussian_filter(norm,.7)
 blobs=blob_log(smooth,min_sigma=3,max_sigma=10,num_sigma=10,threshold=.05,overlap=.5,exclude_border=False)
 t=float(threshold_otsu(smooth));mask=remove_small_objects(smooth>t*.5,min_size=25);mask=remove_small_holes(mask,area_threshold=16)
 markers=np.zeros(mask.shape,dtype='int32');centers=[]
 for y,x,sigma in blobs:
  yy,xx=int(round(y)),int(round(x))
  if mask[yy,xx] and markers[yy,xx]==0:markers[yy,xx]=len(centers)+1;centers.append((yy,xx,float(sigma)))
 labels=watershed(-smooth,markers,mask=mask,connectivity=2)
 sizes=np.bincount(labels.ravel());keep=sizes>=25;keep[0]=False;labels[~keep[labels]]=0;labels,_,_=relabel_sequential(labels)
 labels=labels.astype('uint32');full=ndi.zoom(labels,2,order=0)[:raw.shape[0],:raw.shape[1]]
 if full.shape!=raw.shape:
  a=np.zeros(raw.shape,dtype='uint32');a[:full.shape[0],:full.shape[1]]=full;full=a
 count=int(labels.max())
 if not count:raise ValueError('LoG found zero valid nuclei; quality exception, do not substitute zero')
 if count!=len(np.unique(labels))-1:raise ValueError('Instance IDs are not contiguous')
 return full,dict(n_nuclei=count,candidate_markers=len(centers),discarded_small_regions=int(np.count_nonzero((sizes[1:]>0)&(sizes[1:]<25))),otsu_threshold=t,foreground_threshold=t*.5,normalization_high=hi)
def process(source,out,expected_source_sha256=None):
 source=Path(source);out=Path(out);out.mkdir(parents=True,exist_ok=True)
 sourcehash=sha(source)
 if expected_source_sha256 and sourcehash!=expected_source_sha256:raise ValueError('DAPI source checksum mismatch')
 record=out/'log_record.json'
 if record.exists():
  old=json.loads(record.read_text('utf8'))
  if old['source_sha256']==sourcehash and old['script_sha256']==sha(__file__) and sha(old['labels_path'])==old['labels_sha256'] and sha(old['native_labels_path'])==old['native_labels_sha256']:return old
  raise ValueError('Existing output belongs to a different source/script; use a new directory')
 a=tifffile.imread(source);raw=a[...,2] if a.ndim==3 and a.shape[-1]==3 else a
 labels,stats=segment(raw);props=regionprops(labels)
 nuclei=[dict(nucleus_id=int(p.label),x=float(p.centroid[1]),y=float(p.centroid[0]),area_px2=int(p.area),touches_border=bool(p.bbox[0]==0 or p.bbox[1]==0 or p.bbox[2]==labels.shape[0] or p.bbox[3]==labels.shape[1])) for p in props]
 tifffile.imwrite(out/'dapi_instances_uint32.tif',labels,compression='deflate',metadata=None)
 tifffile.imwrite(out/'dapi_instances_native32.tif',labels.astype('float32'),compression='deflate',metadata=None)
 Image.fromarray((labels>0).astype('uint8')*255).save(out/'foreground_preview.png')
 # A small QC view is retained automatically; it is not a user approval gate.
 h,w=raw.shape;y0=max(0,h//2-368);y1=min(h,y0+736);x0=max(0,w//2-460);x1=min(w,x0+920)
 lo,hi=np.percentile(raw,[1,99.5]);rgb=np.zeros((y1-y0,x1-x0,3),dtype='uint8');rgb[...,2]=np.rint(np.clip((raw[y0:y1,x0:x1].astype('float32')-lo)/max(float(hi-lo),1),0,1)*230).astype('uint8');rgb[find_boundaries(labels[y0:y1,x0:x1],mode='inner')]=[255,255,0];Image.fromarray(rgb).save(out/'automatic_qc_crop.png')
 result=dict(method_id=METHOD_ID,parameters=PARAMETERS,source=str(source),source_sha256=sourcehash,script_sha256=sha(__file__),labels_path=str(out/'dapi_instances_uint32.tif'),labels_sha256=sha(out/'dapi_instances_uint32.tif'),native_labels_path=str(out/'dapi_instances_native32.tif'),native_labels_sha256=sha(out/'dapi_instances_native32.tif'),preview_mask_path=str(out/'foreground_preview.png'),preview_mask_sha256=sha(out/'foreground_preview.png'),stats=stats,nuclei=nuclei,versions=dict(numpy=np.__version__,scipy=scipy.__version__,skimage=skimage.__version__),per_field_human_review_required=False,automatic_qc_passed=True)
 if sha(source)!=sourcehash:raise ValueError('Original source changed during segmentation')
 record.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8');return result
if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--out',required=True);a=p.parse_args();r=process(a.source,a.out);print(json.dumps(r['stats']))
