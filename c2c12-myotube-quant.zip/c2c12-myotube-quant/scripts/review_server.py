from pathlib import Path
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
import json,datetime,threading,secrets,os,argparse,math
parser=argparse.ArgumentParser();parser.add_argument('--port',type=int,default=8767);parser.add_argument('--state-dir');parser.add_argument('--run-root',type=Path,required=True);args=parser.parse_args()
ROOT=args.run_root.resolve();LOCK=threading.Lock();TOKEN=secrets.token_urlsafe(24)
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def active():
 pointer=json.loads((ROOT/'active_review_round.json').read_text(encoding='utf8'));base=(ROOT/pointer['folder']).resolve()
 if base.parent!=ROOT.resolve():raise ValueError('Invalid round folder')
 manifest=json.loads((base/'preview_manifest.json').read_text(encoding='utf8'))
 if not manifest['complete']:raise ValueError('本轮预览尚未完成')
 return base,manifest
BASE,MANIFEST=active();STATE=Path(args.state_dir) if args.state_dir else BASE;STATE.mkdir(parents=True,exist_ok=True)
def state_path(base):return (STATE if args.state_dir else base)/'myhc_feedback.json'
def initial(m):
 return dict(schema_version=2,batch_id=m['batch_id'],manifest_sha256=m['manifest_sha256'],round=m['round'],round_key=m['round_key'],accepted_count=m['accepted_count'],rule='blank_is_accept_on_submit',revision=0,updated_at=None,submitted_at=None,fields=[dict(index=r['index'],group=r['group'],well=r['well'],field=r['field'],myhc_source_sha256=r['source_sha256']['myhc'],myhc_mask_sha256=r['myhc_provenance']['mask_sha256'],previous_myhc_multiplier=r['previous_myhc_multiplier'],current_myhc_multiplier=r['current_myhc_multiplier'],requested_myhc_multiplier=None,decision=None,excluded=False,exclusion_reason=None) for r in m['fields']])
def read_state(base,m):
 p=state_path(base)
 if not p.exists():return initial(m)
 data=json.loads(p.read_text(encoding='utf8'))
 if data['round_key']!=m['round_key']:raise ValueError('意见与当前预览版本不符')
 return data
def atomic(path,data):
 temp=path.with_suffix('.tmp');temp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8');os.replace(temp,path)
class Handler(SimpleHTTPRequestHandler):
 def __init__(self,*a,**kw):base,m=active();super().__init__(*a,directory=str(base),**kw)
 def log_message(self,*a):pass
 def end_headers(self):self.send_header('Cache-Control','no-store');super().end_headers()
 def respond(self,code,obj):
  raw=json.dumps(obj,ensure_ascii=False).encode();self.send_response(code);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
 def do_GET(self):
  base,m=active()
  if self.path=='/api/health':return self.respond(200,dict(ok=True,batch_id=m['batch_id'],round=m['round'],field_count=len(m['fields'])))
  if self.path=='/api/state':
   with LOCK:data=read_state(base,m)
   return self.respond(200,dict(data,token=TOKEN))
  if self.path in ['/','/index.html']:self.path='/review.html'
  if self.path.startswith('/api/'):return self.respond(404,dict(error='Not found'))
  return super().do_GET()
 def do_POST(self):
  if self.path!='/api/reviews':return self.respond(404,dict(error='Not found'))
  origin=self.headers.get('Origin');expected='http://127.0.0.1:'+str(self.server.server_port)
  if origin and origin!=expected:return self.respond(403,dict(error='不允许跨来源保存'))
  if self.headers.get('X-Review-Token')!=TOKEN:return self.respond(403,dict(error='页面已更新，请刷新后保存'))
  if not self.headers.get('Content-Type','').startswith('application/json'):return self.respond(415,dict(error='JSON required'))
  try:
   size=int(self.headers.get('Content-Length',0))
   if not 0<size<=200000:raise ValueError('请求大小不正确')
   body=json.loads(self.rfile.read(size));base,m=active();incoming=body['fields'];canonical={r['index'] for r in m['fields']}
   if body.get('round_key')!=m['round_key']:return self.respond(409,dict(error='已经进入新一轮，请刷新页面'))
   if len(incoming)!=len(canonical) or {r['index'] for r in incoming}!=canonical:raise ValueError('只提交本轮显示的视野，且不可重复')
   with LOCK:
    data=read_state(base,m)
    if body.get('expected_revision')!=data['revision']:return self.respond(409,dict(error='另一页面已更新乘数，请先刷新'))
    indexed={r['index']:r for r in incoming};fields=[]
    for old in data['fields']:
     request=indexed[old['index']];excluded=request.get('excluded',False)
     if not isinstance(excluded,bool):raise ValueError('excluded must be boolean')
     number=None if excluded else request.get('requested_myhc_multiplier')
     if number is not None and (isinstance(number,bool) or not isinstance(number,(int,float)) or not math.isfinite(number) or not 0<number<=1000):raise ValueError('乘数必须是大于0、不超过1000的有限数值；留空表示通过')
     decision=('excluded' if excluded else ('accepted' if number is None else 'change_requested')) if body.get('submit') else None
     fields.append(dict(old,requested_myhc_multiplier=number,decision=decision,excluded=excluded,exclusion_reason='用户在HTML指定该视野数据不纳入计算，文件保留' if excluded else None))
    data.update(fields=fields,revision=data['revision']+1,updated_at=now(),submitted_at=None)
    if body.get('submit'):
     data['submitted_at']=data['updated_at'];snap=(STATE if args.state_dir else base)/'submitted_reviews';snap.mkdir(exist_ok=True);atomic(snap/f'revision_{data["revision"]:04d}.json',data)
    atomic(state_path(base),data)
   return self.respond(200,dict(ok=True,revision=data['revision'],updated_at=data['updated_at'],submitted=bool(body.get('submit')),change_count=sum(r['requested_myhc_multiplier'] is not None and not r['excluded'] for r in fields),accepted_count=sum(r['requested_myhc_multiplier'] is None and not r['excluded'] for r in fields),excluded_count=sum(r['excluded'] for r in fields)))
  except (ValueError,KeyError,TypeError) as e:return self.respond(400,dict(error=str(e)))
server=ThreadingHTTPServer(('127.0.0.1',args.port),Handler);url='http://127.0.0.1:'+str(server.server_port)+'/'
if not args.state_dir:(ROOT/'review_server_runtime.json').write_text(json.dumps(dict(url=url,pid=os.getpid(),round=MANIFEST['round'],feedback_path=str(state_path(BASE))),ensure_ascii=False,indent=2),encoding='utf8')
print('REVIEW_APP_READY '+url,flush=True);server.serve_forever()
