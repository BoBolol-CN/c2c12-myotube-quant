"""Validate the user-confirmed experimental design before measurements."""
import argparse
import hashlib
import json
import math
from collections import Counter
from pathlib import Path


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def validate_manifest(data, require_design=True, check_files=True):
    if not isinstance(data, dict) or not str(data.get('batch_id', '')).strip():
        raise ValueError('A batch_id is required')
    fields = data.get('fields', [])
    if not fields:
        raise ValueError('No fields specified')
    seen, paths = set(), set()
    for row in fields:
        if not all(isinstance(row.get(k), str) and row[k].strip() for k in ['group', 'well', 'field', 'myhc', 'dapi']):
            raise ValueError('Each field requires group, well, field, myhc and dapi')
        key = (row['group'], row['field'])
        if key in seen:
            raise ValueError('Duplicate group/field: ' + str(key))
        seen.add(key)
        for role in ['myhc', 'dapi']:
            p = Path(row[role])
            if not p.is_absolute():
                raise ValueError('Use absolute source paths: ' + str(p))
            canonical = str(p.resolve()).casefold()
            if canonical in paths:
                raise ValueError('Source image reused across channels or fields: ' + str(p))
            paths.add(canonical)
            if check_files and not p.is_file():
                raise FileNotFoundError(p)
    if not require_design:
        return data
    design = data.get('design', {})
    if not (design.get('user_confirmed') is True and design.get('mapping_confirmed') is True and str(design.get('user_response', '')).strip()):
        raise ValueError('Ask user for field counts, well counts and field-to-well mapping before quantification')
    if not isinstance(design.get('biological_replicates_are_wells'), bool):
        raise ValueError('Confirm whether each well is a biological replicate')
    groups = design.get('groups', [])
    names = [x.get('name') for x in groups]
    actual = Counter(r['group'] for r in fields)
    if len(set(names)) != len(names) or set(names) != set(actual):
        raise ValueError('Declared groups must match field groups exactly')
    for group in groups:
        n, wells = group.get('field_count'), group.get('well_count')
        if any(type(v) is not int or v < 1 for v in [n, wells]):
            raise ValueError('Field and well counts must be positive integers confirmed by user')
        selected = [r for r in fields if r['group'] == group['name']]
        if n != len(selected) or wells != len({r['well'] for r in selected}):
            raise ValueError('Field/well counts disagree with mapping: ' + group['name'])
    return data


def validate_pilot(pilot, manifest, manifest_path):
    if pilot.get('batch_id') != manifest['batch_id'] or pilot.get('manifest_sha256') != sha256(manifest_path):
        raise ValueError('Pilot does not match batch/input manifest')
    keys = [(r['group'], r['field']) for r in pilot.get('fields', [])]
    expected = min(5, len(manifest['fields']))
    available = {(r['group'], r['field']) for r in manifest['fields']}
    if len(keys) != expected or len(set(keys)) != expected or not set(keys) <= available:
        raise ValueError('Pilot must contain the expected number of distinct source fields')
    if len({g for g, _ in keys}) != min(5, len({r['group'] for r in manifest['fields']})):
        raise ValueError('Pilot must represent distinct groups before supplementing fields')
    return keys


def validate_review(record, manifest, manifest_path, pilot_keys, myhc_multiplier, dapi_multiplier):
    if not all(math.isfinite(x) and x > 0 for x in [myhc_multiplier, dapi_multiplier]):
        raise ValueError('Multipliers must be finite positive numbers')
    if not (record.get('batch_id') == manifest['batch_id'] and record.get('manifest_sha256') == sha256(manifest_path)):
        raise ValueError('Review does not match input manifest/batch')
    if not (record.get('myhc_approved') is True and record.get('dapi_approved') is True and str(record.get('user_response', '')).strip()):
        raise ValueError('Both channels require explicit user acceptance')
    if record.get('myhc_multiplier') != myhc_multiplier or record.get('dapi_multiplier') != dapi_multiplier:
        raise ValueError('Multipliers differ from reviewed values')
    reviewed = [(r['group'], r['field']) for r in record.get('pilot_fields', [])]
    if len(reviewed) != len(pilot_keys) or set(reviewed) != set(pilot_keys):
        raise ValueError('Review must cover the same pilot fields')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    args = parser.parse_args()
    data = validate_manifest(read_json(args.manifest))
    print(json.dumps({'valid': True, 'fields': len(data['fields']), 'groups': data['design']['groups']}, ensure_ascii=False))
