"""Measure reviewed masks: native ImageJ MyHC area/centroid fusion; approved Python LoG DAPI and diameter."""
import argparse,json,hashlib,shutil,tempfile,subprocess,os,math
from pathlib import Path
import tifffile
from validate_manifest import validate_manifest
from measure_python_diameter import measure_diameter, METHOD
from segment_dapi_log import METHOD_ID as DAPI_METHOD, PARAMETERS as DAPI_PARAMETERS
SKILL=Path(__file__).resolve().parent.parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):
 raw=Path(p).read_bytes()
 try:s=raw.decode('utf-8-sig')
 except UnicodeDecodeError:s=raw.decode('gb18030')
 return json.loads(s)
def check_review(row,role='myhc'):
 key='review_snapshot' if role=='myhc' else 'dapi_review_snapshot'
 decision_key='review_decision' if role=='myhc' else 'dapi_review_decision'
 snapshot=Path(row[key])
 if sha(snapshot)!=row[key+'_sha256']:raise ValueError('Review snapshot checksum mismatch')
 review=load(snapshot)
 if not (review.get('submitted_at') or review.get('user_response')):raise ValueError('Draft is not user acceptance')
 found=[r for r in review['fields'] if (r.get('group'),r.get('field'))==(row['group'],row['field'])]
 if len(found)!=1:raise ValueError('Review does not identify this field uniquely')
 r=found[0]
 if r.get('excluded') or r.get('decision') in ['excluded','change_requested'] or r.get('requested_'+role+'_multiplier') is not None:raise ValueError('Field still needs modification or was excluded')
 if r.get(role+'_mask_sha256')!=row[role+'_provenance']['mask_sha256']:raise ValueError('Review belongs to another mask version')
 if row.get(decision_key)!='accepted':raise ValueError('Only accepted fields may be measured')
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--manifest',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--temp-root',type=Path,default=Path('E:/codex/_temp'));p.add_argument('--imagej',type=Path,default=Path('E:/Study program/Fiji.app/ImageJ-win64.exe'));a=p.parse_args()
 data=validate_manifest(load(a.manifest))
 if data.get('review_complete') is not True:raise ValueError('Finish mandatory HTML review or explicit user decisions first')
 dapi=load(data['dapi_review_record'])
 if not (dapi.get('method_id')==DAPI_METHOD and dapi.get('dapi_method_approved') and dapi.get('automatic_complete') and dapi.get('per_field_human_review_required') is False):raise ValueError('Approved LoG DAPI automatic record required')
 if sha(data['dapi_review_record'])!=data.get('dapi_review_sha256'):raise ValueError('Automatic DAPI record checksum mismatch')
 approval=load(dapi['method_approval_record'])
 if sha(dapi['method_approval_record'])!=dapi['method_approval_sha256'] or not approval.get('method_approved') or not approval.get('user_instruction'):raise ValueError('DAPI method approval missing')
 if a.out.exists():raise FileExistsError('Use a new output directory to preserve results')
 automatic={(r['group'],r['field']):r for r in dapi['fields']}
 if set(automatic)!={(r['group'],r['field']) for r in data['fields']}:raise ValueError('Automatic record field list differs')
 hashes=[]
 for row in data['fields']:
  check_review(row)
  dp=row['dapi_provenance']
  if dp.get('method_id')!=DAPI_METHOD or row.get('dapi_processing_decision')!='automatic_qc_passed':raise ValueError('LoG DAPI instance processing incomplete')
  for key in ['labels','native_labels']:
   if sha(dp[key+'_path'])!=dp[key+'_sha256']:raise ValueError('LoG labels checksum mismatch')
  approved=automatic[(row['group'],row['field'])]
  if approved['labels_sha256']!=dp['labels_sha256'] or approved['n_nuclei']!=row['dapi_n_nuclei']:raise ValueError('Automatic field receipt differs')
  auto=load(dp['processing_record'])
  if auto['method_id']!=DAPI_METHOD or auto['parameters']!=DAPI_PARAMETERS:raise ValueError('Unexpected DAPI method or parameters')
  if sha(dp['processing_record'])!=dp['processing_record_sha256'] or auto['source_sha256']!=row['source_sha256']['dapi'] or auto['stats']['n_nuclei']!=row['dapi_n_nuclei']:raise ValueError('LoG processing record mismatch')
  for role in ['myhc','dapi']:
   prov=row[role+'_provenance']
   if sha(prov['mask_path'])!=prov['mask_sha256']:raise ValueError('Mask checksum mismatch')
  actual_sources={role:sha(row[role]) for role in ['myhc','dapi']}
  if actual_sources!=row.get('source_sha256'):raise ValueError('Original source checksum does not match the reviewed source')
  hashes.append(actual_sources)
 a.out.mkdir(parents=True);a.temp_root.mkdir(parents=True,exist_ok=True)
 shutil.copy2(Path(__file__),a.out/'executed_orchestrator.py');shutil.copy2(SKILL/'scripts/measure_python_diameter.py',a.out/'executed_python_diameter.py')
 if not str(a.temp_root.resolve()).isascii():raise ValueError('Native ImageJ requires ASCII temporary paths')
 for k in ['TEMP','TMP','TMPDIR']:os.environ[k]=str(a.temp_root.resolve())
 work=Path(tempfile.mkdtemp(prefix='native_measure_',dir=a.temp_root));jobs=[]
 for i,row in enumerate(data['fields'],1):
  folder=work/f'f{i:04d}';folder.mkdir();target=a.out/f'field_{i:04d}';target.mkdir()
  shutil.copy2(row['myhc_provenance']['mask_path'],folder/'myhc.png')
  shutil.copy2(row['dapi_provenance']['native_labels_path'],folder/'dapi_instances.tif')
  jobs.append(dict(group=row['group'],well=row['well'],field=row['field'],myhc_mask=(folder/'myhc.png').as_posix(),dapi_labels=(folder/'dapi_instances.tif').as_posix(),debug_folder=folder.as_posix(),output=(folder/'result.json').as_posix()))
 config=dict(jobs=jobs,test_output=(work/'self_tests.json').as_posix());(work/'config.json').write_text(json.dumps(config,ensure_ascii=True),encoding='ascii')
 script=(SKILL/'assets/native_area_fusion.js').read_text(encoding='utf-8-sig').replace('__CONFIG__',(work/'config.json').as_posix());(work/'measure.js').write_text(script,encoding='utf8');(a.out/'executed_measurement.js').write_text(script,encoding='utf8')
 macro='eval("script",File.openAsString("'+(work/'measure.js').as_posix()+'"));\n';(work/'run.ijm').write_text(macro,encoding='ascii');(a.out/'executed_measurement.ijm').write_text(macro,encoding='ascii')
 with (a.out/'imagej_console.log').open('w',encoding='utf8') as log:proc=subprocess.run([str(a.imagej),'--headless','--ij1','--no-splash','--console','--memory','2g','-macro',str(work/'run.ijm')],stdout=log,stderr=subprocess.STDOUT,timeout=3600)
 if proc.returncode:raise RuntimeError('ImageJ failed; preserve '+str(work)+' and inspect imagej_console.log')
 tests=load(work/'self_tests.json')
 if not tests['passed']:raise RuntimeError('Native self tests failed')
 rows=[]
 for i,(row,job) in enumerate(zip(data['fields'],jobs),1):
  result=load(job['output']);s=result['summary']
  if s['n_nuclei_total']!=row['dapi_n_nuclei']:raise ValueError('Native centroid pass changed LoG instance count')
  if result['issues']:raise ValueError('Unresolved field issues: '+str(result['issues']))
  if s['myhc_area_px2']!=sum(r['area_px2'] for r in result['objects']):raise ValueError('Area reconciliation failed')
  if s['n_fusion_nuclei_ge2']!=sum(r['n_nuclei'] for r in result['objects'] if r['n_nuclei']>=2) or s['n_fusion_nuclei_ge2']!=sum(r['eligible'] for r in result['nuclei']):raise ValueError('Fusion reconciliation failed')
  folder=a.out/f'field_{i:04d}'
  for f in Path(job['debug_folder']).glob('*.tif'):tifffile.imwrite(folder/f.name,tifffile.imread(f),compression='deflate',metadata=None)
  diameter=measure_diameter(row['myhc_provenance']['mask_path'],folder/'myhc_labels32.tif',result['objects'],folder)
  s.update(diameter['summary']);by_id={o['object_id']:o for o in diameter['objects']}
  for obj in result['objects']:obj.update(by_id[obj['object_id']])
  native_engine=result['measurement_engine']
  result['measurement_engine']='Hybrid: native ImageJ MyHC area/centroid fusion; Python LoG DAPI and diameter'
  result['metric_engines']={'area':native_engine,'fusion':native_engine,'dapi':'Python approved LoG instance labels','diameter':'Python scikit-image + SciPy'}
  result['diameter_method']=METHOD;result['diameter_versions']=diameter['versions']
  provenance=dict(measurement_engine=result['measurement_engine'],metric_engines=result['metric_engines'],diameter_method=METHOD,diameter_versions=diameter['versions'],original_sources_sha256=hashes[i-1],manual_correction=False,units={'area':'px2','diameter':'px'})
  for role in ['myhc','dapi']:
   prov=row[role+'_provenance']
   if sha(row[role])!=hashes[i-1][role] or sha(prov['mask_path'])!=prov['mask_sha256']:raise ValueError('Source or mask changed during measurement')
   provenance[role+'_mask_path']=prov['mask_path'];provenance[role+'_mask_sha256']=prov['mask_sha256']
  provenance['dapi_method']=DAPI_METHOD;provenance['dapi_labels_path']=row['dapi_provenance']['labels_path'];provenance['dapi_labels_sha256']=row['dapi_provenance']['labels_sha256']
  result.update(row,provenance=provenance);rows.append(result)
  for name,value in [('measurement.json',result),('field_summary.json',s),('myhc_objects.json',result['objects']),('nucleus_assignments.json',result['nuclei'])]:(folder/name).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf8')
 settings=dict(myhc_multiplier='逐视野验收值',dapi_multiplier=None,dapi_method=DAPI_METHOD,dapi_parameters=DAPI_PARAMETERS,min_nuclei_for_fusion=2,extra_filter=False,manual_correction=False,calibration=None,measurement_engine='Hybrid: native ImageJ MyHC segmentation, area and centroid fusion; Python LoG DAPI instances and skeleton/EDT diameter',diameter_method=METHOD)
 payload=dict(version=2,mode='measure',complete=True,batch_id=data['batch_id'],design=data['design'],input_manifest=data,settings=settings,fields=rows,exclusions=data.get('exclusions',[]))
 (a.out/'batch_measurements.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf8');(a.out/'native_self_tests.json').write_text(json.dumps(tests,indent=2),encoding='utf8')
 print('Complete: '+str(a.out/'batch_measurements.json'))
if __name__=='__main__':main()
