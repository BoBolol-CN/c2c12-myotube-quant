"""Apply approved LoG-v1 DAPI automatically to a MyHC-accepted manifest."""
import argparse,json,hashlib,copy
from pathlib import Path
from segment_dapi_log import process,METHOD_ID,PARAMETERS,sha
from validate_manifest import validate_manifest
from measure_reviewed_masks import check_review
def main():
 p=argparse.ArgumentParser();p.add_argument('--manifest',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--method-approval',type=Path,required=True);a=p.parse_args()
 data=validate_manifest(json.loads(a.manifest.read_text('utf-8-sig')));approval=json.loads(a.method_approval.read_text('utf-8-sig'))
 if approval.get('method_id')!=METHOD_ID or not approval.get('method_approved') or not approval.get('user_instruction') or approval.get('per_field_human_review_required') is not False:raise ValueError('Approved LoG method record required')
 if a.out.exists():raise FileExistsError('Use a new output directory')
 a.out.mkdir(parents=True);data=copy.deepcopy(data)
 for i,row in enumerate(data['fields'],1):
  check_review(row)
  record=process(row['dapi'],a.out/f'field_{i:04d}'/'dapi_log',row['source_sha256']['dapi']);folder=Path(record['labels_path']).parent
  row['deprecated_dapi_provenance']=row.pop('dapi_provenance',None)
  for k in ['dapi_review_snapshot','dapi_review_snapshot_sha256','dapi_review_decision','dapi_multiplier','current_dapi_multiplier']:row.pop(k,None)
  row.update(dapi_method=METHOD_ID,dapi_processing_decision='automatic_qc_passed',dapi_review_status='not_required_method_approved',dapi_n_nuclei=record['stats']['n_nuclei'])
  row['dapi_provenance']=dict(method_id=METHOD_ID,labels_path=record['labels_path'],labels_sha256=record['labels_sha256'],native_labels_path=record['native_labels_path'],native_labels_sha256=record['native_labels_sha256'],mask_path=record['preview_mask_path'],mask_sha256=record['preview_mask_sha256'],processing_record=str(folder/'log_record.json'),processing_record_sha256=sha(folder/'log_record.json'),source_sha256=record['source_sha256'])
  (a.out/'checkpoint.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8');print(i,row['group'],row['field'],row['dapi_n_nuclei'],flush=True)
 automatic=dict(method_id=METHOD_ID,dapi_method_approved=True,per_field_human_review_required=False,automatic_complete=True,method_approval_record=str(a.method_approval.resolve()),method_approval_sha256=sha(a.method_approval),fields=[dict(group=r['group'],field=r['field'],labels_sha256=r['dapi_provenance']['labels_sha256'],n_nuclei=r['dapi_n_nuclei']) for r in data['fields']])
 record=a.out/'dapi_automatic_record.json';record.write_text(json.dumps(automatic,ensure_ascii=False,indent=2),encoding='utf8')
 data.update(review_complete=True,myhc_review_complete=True,dapi_method=METHOD_ID,dapi_automatic_complete=True,dapi_review_record=str(record.resolve()),dapi_review_sha256=sha(record))
 for k in ['dapi_review_complete']:data.pop(k,None)
 (a.out/'accepted_input_log.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8')
if __name__=='__main__':main()
