---
name: c2c12-myotube-quant
description: Quantify C2C12 MyHC/DAPI images with user-reviewed ViaFuse segmentation in native ImageJ, same-mask area and skeleton/EDM diameter, fusion index for objects with at least two nuclei, and well-level biological replicates in Excel with Prism column tables.
---
# C2C12 肌管定量：ViaFuse、孔重复与 Excel

## 1. 计算前询问并确认实验设计

先向使用者确认：**每组有几个视野、几个孔，以及哪些视野属于哪个孔？每孔是否代表一个生物学重复？** 同时确认组名、MyHC/DAPI配对与文件范围。已有明确回答时沿用，不重复询问；缺失部分必须问清，不能凭文件数量、文件夹编号或整除关系推断。确认前不计算三项指标或孔均值。

按 [references/data_contract.md](references/data_contract.md) 记录设计、用户回答和逐视野孔归属。每组孔数可以不同，每孔视野数也可以不同。只有用户明确认可顺序分孔时，才按文件名顺序分配；不能把“9视野、3孔”当作所有实验的默认值。

## 2. 随机抽取5张不同照片试跑

用 `scripts/select_pilot.py`：随机选5个不同组，每组随机1个视野；不足5组则覆盖所有组、补足5个不同视野；不足5个视野时如实使用全部。记录随机种子和来源manifest校验值。调整参数仍看同一组照片，不重新抽样规避难例。

## 3. 分别测试 MyHC 和 DAPI 乘数

使用 `scripts/run_batch.py --mode preview --pilot ...`，只输出MyHC纯绿、DAPI纯蓝底图及轮廓。两通道乘数独立，同轮各组使用统一候选参数；**无跨实验固定默认值**。分别让使用者确认肌管轮廓和核轮廓，未确认前不自动计核、不计算面积/直径/融合指数、不扩展全批。

显示副本适当提亮，使弱信号可见：绿P1–P99、蓝P1–P99.5归一化后，`clip((sqrt(base)-0.1)*1.2+0.1,0,1)`。显示增强不回流分割。不能用合并图代替纯通道确认。

## 4. 记录验收，执行 ViaFuse 批量分割

依据用户明确反馈填写两通道验收记录，绑定batch_id、输入manifest SHA256、试跑视野及乘数。已有本批确认不重复询问，新批次重新试跑。2026-11-14/15的1-15、1-16使用MyHC=7、DAPI=1，只是历史批次记录。

运行本机 `E:/Study program/Fiji.app/ImageJ-win64.exe --headless --ij1`，不直接调用java.exe，不需Computer Use。ViaFuse原版F/V Windows宏及来源校验在 `assets/viafuse/`；提取作者分割步骤执行，不把整份交互宏的手工核数修正带入流程。

- MyHC：uint16原始绿色通道 → 用户确认的Multiply → Gaussian sigma=2、Default dark阈值、Close、Median radius=1。
- DAPI：uint16原始蓝色通道 → 用户确认的Multiply → Default dark阈值、Median radius=1、Close、Watershed。

原图只读，在工作副本上乘法。记录uint16饱和风险和乘数；中文路径经英文临时路径无损副本交给ImageJ。保留实际宏、日志和白前景掩膜。不得恢复旧自定义Li/Otsu流程、另加尺寸/形状筛选或人工核团面积估核。

## 5. 三项指标使用同一份已验收的掩膜

使用 `scripts/measure_masks.py`，不重新分割：

1. **MyHC阳性面积**：全部MyHC前景像素，报告px²和全视野百分比；不按核数删对象。
2. **肌管直径**：对每个8连通MyHC对象，取补零边界的局部掩膜做骨架和欧氏距离变换；局部直径=2r，先求对象骨架上的均值，再按对象等权求视野均值/中位数。包括无核、单核对象，不额外过滤碎片，不用Feret替代。Python骨架+EDM是本项目扩展，不能称为ViaFuse作者认证或原版自带功能。
3. **融合指数**：DAPI分水岭后8连通对象作为核，以核质心（四舍五入至像素）归属MyHC对象。**仅含≥2个核的MyHC对象内核数 / 全视野DAPI核数 ×100%。** 单核对象不进入分子；框外核不因部分重叠或邻近纳入。不做人工核数修正。这是本项目口径，不冒称原论文的≥3核结果。

没有有效长度校准时直径只用px、面积用px²；不套用原文µm²核面积过滤，不编造µm。零核时融合指数留空并标记；空掩膜、缺失配对、源图改变、指标不一致均记录需复核，暂停汇总，不把缺失视野当0或悄悄少算后取平均。发现实际轮廓明显漏检/合并时先预览复核，不给单张图悄悄更换参数。

## 6. 按用户确认的孔归属计算生物学重复

`run_batch.py --mode measure` 在定量前强制校验已确认的视野数、孔数及逐视野归属，并校验两通道验收。核对每孔所有预期视野均有结果，再对**视野级指标取算术平均**。融合指数先逐视野算比例，再取孔均值，不用合并核数后的比例代替。每孔一个数值，n为用户确认的独立孔数；不把视野当独立生物学重复，不混淆孔内视野与孔重复。技术孔不自行宣称生物学重复。

## 7. 输出一个 Excel，附 Prism 列格式

使用 `scripts/export_excel.mjs`；执行办法见 [references/execution.md](references/execution.md)。按用户已认可排版：

- 左侧：每视野一行，保留面积、直径、核数和融合指数，附组名、孔号。
- 右侧：分别明确标注“融合指数（%）”“MyHC阳性面积比例（%）”“肌管直径均值（px）”“MyHC阳性面积（px²）”。每块首行为样本/组名，每列下方为对应孔均值，可复制到Prism Column表；每组有几个孔就放几个数值。
- 右侧百分比为0–100的数值，便于Prism粘贴；保留AVERAGE公式及孔标签，以便追溯；无冻结行列，无拆分窗格。
- **最终交付.xlsx，不用CSV代替。** JSON与对象/核明细是可追溯的中间资料，不强迫用户阅读。

检查原图校验值、掩膜路径/SHA256、面积与对象面积和、≥2核分子与核归属明细、所有孔均值及Excel公式；预览检查不遮挡标题和单位。若用户仅修改表格，不重复分割。

用户临时要求的图片与数字核验拼图不纳入本skill的固定输出或步骤。

## 软件与入口

依赖本机Fiji/ImageJ（已验证1.52i）及Python：numpy、scipy、scikit-image、tifffile、Pillow。`@oai/artifact-tool`用于Excel；利用表格运行库与spreadsheets技能的导出校验流程。无MATLAB依赖，不使用MyoCount。

`validate_manifest.py`负责设计与验收校验；`select_pilot.py`抽样；`run_viafuse.py`负责原生ImageJ通道分割/预览；`measure_masks.py`负责≥2核定量；`run_batch.py`串联批处理；`export_excel.mjs`负责孔均值和Excel。所有路径与示例见上述两个reference文件。
