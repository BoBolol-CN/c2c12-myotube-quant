/* Measurements run inside native ImageJ/Rhino. No Python image measurements. */
var IJ=Packages.ij.IJ, ImagePlus=Packages.ij.ImagePlus;
var BP=Packages.ij.process.ByteProcessor, FF=Packages.ij.process.FloodFiller;
var EDM=Packages.ij.plugin.filter.EDM, FileSaver=Packages.ij.io.FileSaver;
function label8(bp){
 var fp=bp.convertToFloat();fp.multiply(-1/255);var p=fp.getPixels(),w=bp.getWidth(),count=0,fill=new FF(fp);
 for(var i=0;i<p.length;i++)if(p[i]==-1){count++;fp.setValue(count);fill.fill8(i%w,Math.floor(i/w));}
 return {ip:fp,pixels:p,count:count};
}
function properties(lab,w,h){
 var a=[null];for(var k=1;k<=lab.count;k++)a.push({id:k,area:0,sx:0,sy:0,minx:w,miny:h,maxx:-1,maxy:-1,n_nuclei:0});
 var x=0,y=0,p=lab.pixels;
 for(var i=0;i<p.length;i++){var id=p[i]|0;if(id>0){var o=a[id];o.area++;o.sx+=x;o.sy+=y;if(x<o.minx)o.minx=x;if(x>o.maxx)o.maxx=x;if(y<o.miny)o.miny=y;if(y>o.maxy)o.maxy=y;}x++;if(x==w){x=0;y++;}}
 return a;
}
function saveTiff(ip,path,title){var image=new ImagePlus(title,ip);if(!new FileSaver(image).saveAsTiff(String(path)))throw Error('Cannot save '+path);}
function analyze(m,n,folder){
 var w=m.getWidth(),h=m.getHeight();if(w!=n.getWidth()||h!=n.getHeight())throw Error('Mask sizes differ');
 if(!m.isBinary()||!n.isBinary())throw Error('Masks must be 0/255');
 var ml=label8(m),nl=label8(n),mp=properties(ml,w,h),np=properties(nl,w,h),nuclei=[],objects=[],diams=[],area=0;
 for(var id=1;id<=nl.count;id++){var no=np[id],cx=no.sx/no.area,cy=no.sy/no.area,ix=Math.min(w-1,Math.floor(cx+.5)),iy=Math.min(h-1,Math.floor(cy+.5)),oid=ml.pixels[iy*w+ix]|0;if(oid>0)mp[oid].n_nuclei++;nuclei.push({nucleus_id:id,x:cx,y:cy,myhc_object_id:oid});}
 var edm=new EDM(),globalSkel=new BP(w,h),globalDiameter=new Packages.ij.process.FloatProcessor(w,h);
 var skeletonPixels=globalSkel.getPixels(),diameterPixels=globalDiameter.getPixels();
 for(var id=1;id<=ml.count;id++){
  var o=mp[id],cw=o.maxx-o.minx+3,ch=o.maxy-o.miny+3,crop=new BP(cw,ch),cp=crop.getPixels();
  for(var y=o.miny;y<=o.maxy;y++)for(var x=o.minx;x<=o.maxx;x++)if(ml.pixels[y*w+x]==id)crop.set(x-o.minx+1,y-o.miny+1,255);
  var distance=edm.makeFloatEDM(crop,0,false),dp=distance.getPixels(),skel=crop.duplicate();skel.invert();skel.skeletonize();skel.invert();var sp=skel.getPixels(),sum=0,ns=0;
  for(var j=0;j<sp.length;j++)if((sp[j]&255)>0){var d=2*Number(dp[j]);sum+=d;ns++;var gx=o.minx+(j%cw)-1,gy=o.miny+Math.floor(j/cw)-1,gi=gy*w+gx;skeletonPixels[gi]=-1;diameterPixels[gi]=d;}
  if(ns==0)throw Error('Object has no skeleton: '+id);
  var mean=sum/ns;diams.push(mean);area+=o.area;objects.push({object_id:id,area_px2:o.area,diameter_px:mean,skeleton_pixels:ns,n_nuclei:o.n_nuclei,eligible:o.n_nuclei>=2});
 }
 var inside=0,single=0,fusion=0,ge2=0,zero=0,eligibleNuclei=0;
 for(var k=0;k<objects.length;k++){var o=objects[k];inside+=o.n_nuclei;if(o.n_nuclei==1)single++;if(o.n_nuclei==0)zero++;if(o.eligible){fusion+=o.n_nuclei;ge2++;}}
 for(var k=0;k<nuclei.length;k++){var r=nuclei[k],oid=r.myhc_object_id;r.eligible=oid>0&&mp[oid].n_nuclei>=2;r.assignment=oid==0?'outside':(mp[oid].n_nuclei==1?'single_nucleus_excluded':'ge2_nuclei_included');if(r.eligible)eligibleNuclei++;}
 if(area!=m.getHistogram()[255])throw Error('Native histogram/object area mismatch');
 if(fusion!=inside-single||fusion!=eligibleNuclei)throw Error('Fusion reconciliation failed');
 var sum=0;for(var k=0;k<diams.length;k++)sum+=diams[k];diams.sort(function(a,b){return a-b;});var median=diams.length?(diams.length%2?diams[(diams.length-1)/2]:(diams[diams.length/2-1]+diams[diams.length/2])/2):null;
 var summary={field_area_px2:w*h,myhc_area_px2:area,myhc_area_fraction:area/(w*h),n_objects:ml.count,diameter_mean_px:diams.length?sum/diams.length:null,diameter_median_px:median,n_nuclei_total:nl.count,n_nuclei_in_myhc:inside,n_nuclei_single_objects:single,n_fusion_nuclei_ge2:fusion,fusion_fraction:nl.count?fusion/nl.count:null,n_objects_ge2:ge2,n_objects_zero:zero};
 var issues=[];if(!ml.count)issues.push('empty_myhc_mask');if(!nl.count)issues.push('zero_dapi_nuclei');
 if(folder){saveTiff(ml.ip,folder+'/myhc_labels32.tif','MyHC labels');saveTiff(nl.ip,folder+'/dapi_labels32.tif','DAPI labels');saveTiff(globalSkel,folder+'/skeleton.tif','Skeleton');saveTiff(globalDiameter,folder+'/diameters_on_skeleton32.tif','Local diameters');}
 return {summary:summary,objects:objects,nuclei:nuclei,issues:issues,measurement_engine:'Native ImageJ '+IJ.getVersion()+' / embedded JavaScript with native FloodFiller.fill8, black-foreground ByteProcessor.skeletonize(), EDM.makeFloatEDM',diameter_method:'Per 8-connected object: zero-padded crop, native ImageJ skeleton and floating EDM, mean 2r on skeleton; equal object weights across the field. Native ImageJ EDM approximation.'};
}
function assertTrue(value,message){if(!value)throw Error('SELF TEST: '+message);}
function selfTests(){
 var m=new BP(20,12),n=new BP(20,12);for(var y=3;y<=7;y++)for(var x=2;x<=8;x++)m.set(x,y,255);for(var y=2;y<=3;y++)for(var x=12;x<=13;x++)m.set(x,y,255);m.set(0,0,255);m.set(1,1,255);n.set(3,3,255);n.set(7,4,255);n.set(12,2,255);n.set(18,9,255);
 var r=analyze(m,n,null);assertTrue(r.summary.myhc_area_px2==41,'area, holes and borders');assertTrue(r.summary.n_objects==3,'8-connectivity includes diagonal pair');assertTrue(r.summary.n_nuclei_total==4&&r.summary.n_fusion_nuclei_ge2==2&&r.summary.fusion_fraction==.5,'ge2 fusion and single-nucleus exclusion');
 var m=new BP(8,8),n=new BP(8,8);m.set(4,4,255);n.set(3,4,255);n.set(4,4,255);var r=analyze(m,n,null);assertTrue(r.nuclei[0].x==3.5&&r.nuclei[0].myhc_object_id==1,'centroid rounds half-up');assertTrue(r.summary.diameter_mean_px==2,'singleton padded EDM diameter');
 var m=new BP(8,8),n=new BP(8,8);for(var y=2;y<=4;y++)for(var x=2;x<=4;x++)if(x!=3||y!=3)m.set(x,y,255);n.set(3,3,255);var r=analyze(m,n,null);assertTrue(r.summary.myhc_area_px2==8&&r.nuclei[0].myhc_object_id==0,'hole preserved and hole nucleus outside');
 return {passed:true,tests:['8-connected diagonal and edge objects','native histogram area reconciliation','ge2 fusion and single nucleus exclusion','half-up centroid assignment','singleton padded skeleton diameter=2px','hole preservation']};
}
try{
 var config=JSON.parse(String(IJ.openAsString('__CONFIG__'))),tests=selfTests();IJ.saveString(JSON.stringify(tests),String(config.test_output));IJ.log('NATIVE_SELF_TESTS_PASSED');
 for(var j=0;j<config.jobs.length;j++){
  var job=config.jobs[j],started=java.lang.System.currentTimeMillis();IJ.log('MEASURE '+(j+1)+'/'+config.jobs.length+' '+job.group+' '+job.field);
  var mi=IJ.openImage(String(job.myhc_mask)),ni=IJ.openImage(String(job.dapi_mask));if(mi==null||ni==null)throw Error('Mask open failed');
  var result=analyze(mi.getProcessor(),ni.getProcessor(),String(job.debug_folder));result.group=job.group;result.well=job.well;result.field=job.field;
  IJ.saveString(JSON.stringify(result),String(job.output));mi.close();ni.close();IJ.log('DONE '+job.field+' objects='+result.summary.n_objects+' nuclei='+result.summary.n_nuclei_total+' ms='+(java.lang.System.currentTimeMillis()-started));
  if(result.issues.length)throw Error('Field issues '+result.issues.join(','));java.lang.System.gc();
 }
 IJ.log('NATIVE_MEASUREMENTS_COMPLETE');java.lang.System.exit(0);
}catch(error){IJ.log('NATIVE_ERROR '+error);java.lang.System.exit(2);}
