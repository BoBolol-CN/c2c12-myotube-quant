# 输入、实验设计与验收记录

计算前询问使用者：“每组有多少个视野、多少个孔？各视野分别属于哪个孔，每孔是否为一个独立生物学重复？” 下例仅示意结构，不是默认孔数。必须依据真实回答填写，不自行生成用户批准。

```json
{
  "batch_id": "experiment-unique-id",
  "design": {
    "user_confirmed": true,
    "mapping_confirmed": true,
    "biological_replicates_are_wells": true,
    "user_response": "使用者的实际回答或对应对话记录",
    "groups": [{"name": "组A", "field_count": 2, "well_count": 2}]
  },
  "fields": [
    {"group": "组A", "well": "孔1", "field": "F01", "myhc": "E:/data/F01_MyHC.tif", "dapi": "E:/data/F01_DAPI.tif"},
    {"group": "组A", "well": "孔2", "field": "F02", "myhc": "E:/data/F02_MyHC.tif", "dapi": "E:/data/F02_DAPI.tif"}
  ]
}
```

每个group/field组合唯一；所有myhc/dapi文件配对唯一且不可跨视野复用。字段与孔映射显式保存，不由程序按9/3猜测。数组顺序为报告顺序，孔顺序为各组在fields中的首次出现顺序。用脚本生成随机pilot记录（包含input manifest SHA256）后保持该文件不变；修改实验设计或配对后重新确认相应记录。

验收文件：

```json
{
  "batch_id": "experiment-unique-id",
  "manifest_sha256": "实际输入manifest的SHA256",
  "myhc_multiplier": 7,
  "dapi_multiplier": 1,
  "myhc_approved": true,
  "dapi_approved": true,
  "user_response": "使用者对两通道轮廓的实际确认",
  "pilot_fields": [{"group": "组A", "field": "F01"}, {"group": "组A", "field": "F02"}]
}
```

7/1只是结构示例，需替换为当前批次测试认可值。pilot_fields必须与select_pilot.py的结果一致，两通道都通过后才填写approved。不足5个可用视野时使用全部；其余批次必须5个不同视野。

批量输出 `batch_measurements.json` 含version、batch_id、design、fields及settings。每个fields记录包含group/well/field、summary、objects、nuclei、provenance及issues。Excel只接受全量、无未解决issues且通过设计校验的数据；缺失或零核不使用少于预期数量的AVERAGE蒙混过关。
