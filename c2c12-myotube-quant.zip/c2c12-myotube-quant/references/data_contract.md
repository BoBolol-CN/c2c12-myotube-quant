# 设计、审阅和排除契约

保存原始设计（全部计划视野/孔归属）与纳入设计，不能由文件数推断。排除仅改变纳入集合，不删除原始行或文件。`design.groups[].field_count` 为测量时的纳入数量；`original_design` 保留原计划；`exclusions` 每条含group、well、field、reason、用户指令来源。

测量manifest必须包含：
- batch_id、design（user_confirmed、mapping_confirmed、biological_replicates_are_wells、user_response、groups）。
- review_complete=true、dapi_review_record（实际验收JSON路径）。
- fields：每个纳入视野的group/well/field、myhc/dapi原图路径、myhc_multiplier、review_decision=accepted、review_snapshot实际路径和SHA256。
- 每行myhc_provenance和dapi_provenance：mask_path、mask_sha256；审阅快照中对应myhc_mask_sha256必须与当前掩膜一致。
- 原始数据SHA256、排除列表及逐孔保留视野列表。被排除的视野不放进测量fields，不填0，也不作为分母。

HTML意见schema2：`round_key`、`revision`、`submitted_at`、`fields`。每行含原index、group/well/field、current_myhc_multiplier、myhc_mask_sha256、requested_myhc_multiplier（空或正数）、excluded（布尔）及exclusion_reason。只有提交快照才产生决定：excluded=true→excluded；否则空乘数→accepted；非空→change_requested。保留所有提交快照。

聊天中明确通过/排除同样记录实际原话与掩膜校验值，不伪造用户批准。待重跑、缺配对、漏跑不能伪装成排除。

每孔保留k个视野，k>=1时孔值为这k个视野指标的算术平均（k=1直接使用该值）；k=0为不可用，明确有效孔数。融合指数先逐视野算，再按孔平均，不合并核数。

测量来源逐指标记录：面积、核归属、融合指数为原生ImageJ；直径为Python/scikit-image骨架及SciPy精确EDT。两阶段使用同一已验收MyHC掩膜及原生8连通对象标签；对象ID和范围须一致。保留直径包版本与方法，不把混合流程写为全部ImageJ，也不恢复旧Python全指标入口。

DAPI须在MyHC确认完后单独逐张验收。每个fields行另含dapi_review_decision=accepted、dapi_review_snapshot、dapi_review_snapshot_sha256；DAPI提交快照记录dapi_mask_sha256、requested_dapi_multiplier、decision及submitted_at。方法参数获批与具体视野掩膜获批分开，后者不可省略。
