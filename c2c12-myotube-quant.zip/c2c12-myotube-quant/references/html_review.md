# 必选HTML审阅

1. 用原生ImageJ生成全部候选掩膜和纯通道/轮廓预览，先不计核、不算指标。`run_batch.py --mode preview` 默认直接生成全批预览，不抽样、不需要pilot。
2. `python <skill>/scripts/build_review.py --run-root <run> --preview-dir <run>/preview-round1`。输入为已有 `preview_manifest.json` 或 `pilot_previews.json`，目录中每张图有 `field_NNNN/myhc/pure_channel.png`、`contours.png`、`mask.png`。构建器不会分割或测量。
3. `python <skill>/scripts/review_server.py --run-root <run> --port 8767`。Windows后台启动用Start-Process -WindowStyle Hidden，或使用保留会话。服务必须在用户填写期间继续运行。通过浏览器打开打印出的本机URL；不要只交付file://页面并依赖无法读取的浏览器缓存。
4. 首轮展示全部图像。用户仅填需修改的MyHC乘数，默认空白。提交时空白=通过，非空=重跑请求；不显示OK/不OK。独立的“不纳入计算”标记只排除数据，不删除任何文件。
5. 读取本机 `myhc_feedback.json` 和 `submitted_reviews/`；无需让用户上传或截图意见。每轮绑定batch、轮号、源manifest、显示掩膜SHA256。自动保存的草稿不等于正式验收。
6. 下一轮只重跑并显示非空请求，保持原视野编号。通过的视野保留原掩膜与验收快照，排除的视野保留文件及原因。新预览输入栏重新置空；用户提交新轮次后才通过新掩膜。图像URL加round_key避免缓存旧图。
7. 必须先完成MyHC阶段，再进入单独DAPI阶段。沿用DAPI参数只代表方法复用，不能当作逐图通过。MyHC全通过后运行 `build_dapi_review.py --run-root <run> --default-multiplier <本批已选DAPI乘数>`，再运行 `review_server.py --channel dapi --run-root <run> --port 8769`。该阶段左侧纯DAPI/黄色核轮廓，右侧仅填写需修改的DAPI乘数；空白提交=该版DAPI通过，下一轮只重跑/显示非空请求。MyHC掩膜保留不动。
8. DAPI使用独立active_dapi_review_round.json、dapi_feedback.json和各轮提交快照。全部通过或明确排除后，为每个纳入视野记录dapi_review_decision=accepted、dapi_review_snapshot及其SHA256，并核对快照dapi_mask_sha256与实际掩膜一致；汇总dapi_channel_review.json。两通道均完成后才构建测量manifest，不得只凭旧的DAPI方法批准进入定量。

本机服务不直接触发ImageJ。使用者提交并告知“填好了”后，由助手读取记录执行相应试跑，避免后台改图造成审阅版本混淆。
