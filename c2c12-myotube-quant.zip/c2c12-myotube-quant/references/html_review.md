# 必选HTML审阅

1. 用原生ImageJ生成全部MyHC候选掩膜和纯通道/轮廓预览，先不计核、不算指标。`run_batch.py --mode preview` 默认直接生成全批预览，不抽样、不需要pilot。
2. `python <skill>/scripts/build_review.py --run-root <run> --preview-dir <run>/preview-round1`。输入为已有 `preview_manifest.json` 或 `pilot_previews.json`，目录中每张图有 `field_NNNN/myhc/pure_channel.png`、`contours.png`、`mask.png`。构建器不会分割或测量。
3. `python <skill>/scripts/review_server.py --run-root <run> --port 8767`。Windows后台启动用Start-Process -WindowStyle Hidden，或使用保留会话。服务必须在用户填写期间继续运行。通过浏览器打开打印出的本机URL；不要只交付file://页面并依赖无法读取的浏览器缓存。
4. 首轮展示全部图像。用户仅填需修改的MyHC乘数，默认空白。提交时空白=通过，非空=重跑请求；不显示OK/不OK。独立的“不纳入计算”标记只排除数据，不删除任何文件。
5. 读取本机 `myhc_feedback.json` 和 `submitted_reviews/`；无需让用户上传或截图意见。每轮绑定batch、轮号、源manifest、显示掩膜SHA256。自动保存的草稿不等于正式验收。
6. 下一轮只重跑并显示非空请求，保持原视野编号。通过的视野保留原掩膜与验收快照，排除的视野保留文件及原因。新预览输入栏重新置空；用户提交新轮次后才通过新掩膜。图像URL加round_key避免缓存旧图。
7. MyHC全部通过或明确排除后，直接运行已批准的 `segment_dapi_log.py` 自动处理DAPI。用户于2026-11-16取消DAPI逐图审阅要求；不要默认构建DAPI待审页面或索要DAPI提交。旧 `build_dapi_review.py` 与 `--channel dapi` 仅保留历史兼容或用户明确要求人工展示时使用。
8. 保留LoG实例标签、质心、源图/脚本/标签SHA256及版本、自动QC和方法批准来源。DAPI不要求逐图review_snapshot；不能伪造人工accepted，使用自动处理完成状态。详见 [DAPI LoG数据契约](dapi_log.md)。

本机审阅服务不直接触发ImageJ。MyHC提交并告知完成后，由助手读取记录重跑；MyHC通过后继续自动DAPI及测量，不在DAPI人为停工。
