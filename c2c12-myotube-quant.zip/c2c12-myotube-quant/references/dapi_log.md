# DAPI：已批准LoG-v1自动方法

2026-11-16用户明确选择试图#01计数1145的“刚才LoG方法”，要求以后DAPI全部使用该方法，并取消逐张人工审阅。批准的是LoG试验，不是随后恢复的历史Median/Otsu/距离变换与面积圆度筛选版；后者试得808/905，不作为当前方法。

## 算法冻结

入口为`scripts/segment_dapi_log.py`，方法ID `python_dapi_log_v1`。以下步骤与批准的试图脚本一致，回归应逐像素复现#01的1145与#02的1152个实例：

1. 原始uint16蓝通道；不乘DAPI亮度乘数。使用SciPy zoom(factor=0.5,order=1)在半分辨率分析。
2. 半分辨率高斯背景sigma=25，原图等效50px；减背景并截负值为0；除以校正图P99.8，归一化后clip到0–1；Gaussian sigma=0.7（原图1.4px）。
3. scikit-image blob_log：min_sigma=3、max_sigma=10、num_sigma=10、threshold=0.05、overlap=0.5、exclude_border=False。sigma范围为原图6–20px。
4. 平滑图Otsu阈值乘0.5作为前景；去除半分辨率小于25px²前景，填小于16px²孔洞；只保留落在前景内的LoG核中心作为标记，重复像素中心去重。
5. 对负平滑强度做标记分水岭，connectivity=2。过滤半分辨率小于25px²的实例（原图等效100px²），重新连续编号；不使用历史圆度或4000px²上限过滤。
6. nearest-neighbor zoom(order=0,factor=2)回原分辨率并与原图对齐；奇数尺寸沿用批准脚本的裁切/补零规则。实例ID和质心来自最终全分辨率标签；边缘对象保留。

默认固定这些参数，不逐图按希望的核数或显著性调参。成像规格或实际异常需要改算法时保留新版本和原因，不把不同参数结果冒充同一批准方法。

## 标签和融合

输出`dapi_instances_uint32.tif`、供ImageJ读取的相同ID浮点32位TIFF、实例质心/面积、`log_record.json`和自动QC小图。二值`foreground_preview.png`只供显示；相邻实例可接触，**不能用其8连通块重新计核**。ImageJ读取实例ID直接求逐核质心，与已验收MyHC对象做归属和≥2核融合计算；原生核数必须等于LoG实例数。原生自检包含两个相邻标签仍为两个核。

## 方法批准与自动契约

方法批准JSON保存method_id、method_approved=true、per_field_human_review_required=false、真实user_instruction和来源、参数。它不是逐图人工通过记录。

对已有MyHC验收manifest运行：

```text
python scripts/run_log_dapi_batch.py --manifest accepted_myhc.json --out 新目录 --method-approval method_approval.json
```

新manifest保持MyHC快照/校验与排除记录，并含：

- dapi_method=python_dapi_log_v1、dapi_automatic_complete=true；旧兼容键dapi_review_record指向自动记录，dapi_review_sha256校验该记录。
- 自动记录：method_id、dapi_method_approved=true、automatic_complete=true、per_field_human_review_required=false、方法批准路径与SHA256，以及逐图标签SHA256和实例数。
- 逐图：dapi_processing_decision=automatic_qc_passed、dapi_n_nuclei、dapi_method；dapi_provenance含method_id、labels_path/labels_sha256、native_labels_path/native_labels_sha256、processing_record/processing_record_sha256、源图SHA256及仅用于显示的mask_path/mask_sha256。
- 不再要求dapi_review_snapshot或逐图人工accepted，不能伪造它们；保留旧结果在deprecated记录用于追溯。

自动核验源图、标签、原生标签和处理脚本SHA256及包版本；实例ID连续、正整数、数量与质心条数一致、原生总数一致。零核/空图/配对不明/来源改变等实际异常必须核查，不能用0或静默排除掩盖。保留必要QC图供助手核验，不默认交用户逐张选择。

旧DAPI方法重算时，旧核数、核归属、融合指数及其Excel/Prism汇总失效。保留原始文件和MyHC已验收结果；仅在核对同一掩膜及对象集后复用面积和直径。输出新版本并明确方法ID，不把旧文件继续称作当前结果。
