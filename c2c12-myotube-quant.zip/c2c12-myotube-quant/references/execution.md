# 执行入口

所有输出与临时目录使用E盘。PowerShell中用&运行带空格路径，TEMP/TMP/TMPDIR设为E:/codex/_temp。原图只读。

1. 确认设计后运行 `validate_manifest.py --manifest <run>/input.json`。不抽样、不生成pilot。
2. 通过 `run_batch.py --mode preview --manifest ... --out ... --myhc-multiplier 候选 --dapi-multiplier 候选` 直接生成本批全部视野的预览（不测量），随后用HTML逐张审阅。全量是默认行为，无需--pilot或--all-fields。
3. 按 [HTML审阅流程](html_review.md) 构建并打开左右布局页面。读取真实提交快照；后续只生成待修改视野，保留此前通过与排除记录。逐视野参数按用户填写，默认留空通过。
4. 建立 [已审阅的数据契约](data_contract.md)，排除记录与纳入字段分开。运行 `measure_reviewed_masks.py --manifest <run>/accepted_input.json --out <run>/measure --temp-root E:/codex/_temp`。原生脚本先做已知图形自检，再测面积、核归属与融合指数；Python从同一已验收MyHC掩膜和原生对象标签计算骨架/精确EDT直径。旧measure_native_imagej.py仅兼容转到此入口。
5. 核对原图/掩膜SHA256、面积与对象面积和、≥2核分子与核归属、实际纳入视野数及每孔k个视野。保留原生宏、日志、标签图，以及Python骨架/局部直径图、脚本、包版本和JSON；检查失败暂停汇总。

## Excel
按spreadsheets技能先load_workspace_dependencies，使用应用自带Node及@oai/artifact-tool。把 `export_excel.mjs` 复制到当前批次可写workbook_code，在该目录建node_modules junction指向运行库，不能修改运行库。第一次创建前成功运行一次mark_artifact_operation_started.mjs。

`node <run>/workbook_code/export_excel.mjs --input <run>/measure/batch_measurements.json --output <run>/C2C12_定量与Prism.xlsx`

核对所有AVERAGE公式恰好覆盖各孔保留的k个视野；排除数据不填零。右侧百分比为0–100，导出.xlsx且无冻结/拆分窗格。预览检查各页标题、单位、孔标签和排除说明。不因排版再次分割。
