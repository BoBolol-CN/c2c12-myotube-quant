# 执行入口

所有输出与临时目录使用E盘。PowerShell中用&运行带空格路径，TEMP/TMP/TMPDIR设为E:/codex/_temp。原图只读。

1. 确认设计后运行 `validate_manifest.py --manifest <run>/input.json`。不抽样、不生成pilot。
2. 通过 `run_batch.py --mode preview --manifest ... --out ... --myhc-multiplier 候选 ` 直接生成本批全部视野的预览（不测量），随后用HTML逐张审阅。全量是默认行为，无需--pilot或--all-fields。
3. 按 [HTML审阅流程](html_review.md) 构建并打开左右布局页面。读取真实提交快照；后续只生成待修改视野，保留此前通过与排除记录。逐视野参数按用户填写，默认留空通过。MyHC全部确认后，直接按DAPI LoG契约自动处理，不要求DAPI逐图审阅。
4. 建立 [已审阅的数据契约](data_contract.md)，排除记录与纳入字段分开。运行 `measure_reviewed_masks.py --manifest <run>/accepted_input.json --out <run>/measure --temp-root E:/codex/_temp`。先使用scripts/segment_dapi_log.py对纳入视野生成DAPI实例标签和自动记录，保存方法批准来源；原生脚本自检后测MyHC面积、读取LoG实例求质心归属与融合指数，核数须与LoG一致。Python从同一已验收MyHC掩膜和原生对象标签计算骨架/精确EDT直径。旧measure_native_imagej.py仅兼容转到此入口。
5. 核对原图/掩膜SHA256、面积与对象面积和、≥2核分子与核归属、实际纳入视野数及每孔k个视野。保留原生宏、日志、标签图，以及Python骨架/局部直径图、脚本、包版本和JSON；检查失败暂停汇总。

## Excel
按spreadsheets技能先load_workspace_dependencies，使用应用自带Node及@oai/artifact-tool。把 `export_excel.mjs` 复制到当前批次可写workbook_code，在该目录建node_modules junction指向运行库，不能修改运行库。第一次创建前成功运行一次mark_artifact_operation_started.mjs。

`node <run>/workbook_code/export_excel.mjs --input <run>/measure/batch_measurements.json --output <run>/C2C12_定量与Prism.xlsx`

默认生成“视野安排 → Prism汇总 → 原始视野数据 → 参数与排除”四个sheet。孔位由原始确认manifest与排除列表共同建立；有完全排除的孔时保留空位置。C列只存可调整的MyHC视野编号，公式查找同一条原始测量，不随编号携带旧孔号。第二个sheet按固定孔位对非空位置取AVERAGE，含四块指标和每孔有效视野数。具体编辑、核验和导入见 [Excel映射与Prism导入](excel_prism.md)。

只有完整的已审阅测量批次可导出。保留输入验证及原始孔归属；已排除视野不可作为可选编号。核对初始均值、所有公式缓存，实际交换编号验证联动，空孔不填零。百分比汇总为0–100，导出.xlsx且无冻结/拆分窗格。预览各页标题、单位、孔标签和排除说明；不因排版再次分割。

## Prism
以当前Excel第二个sheet的重算结果导入三个指标到同一原生Prism工程。使用用户模板；超过9组时循环9色，组色在三个图中一致。保存后重新核对数据表和导出图，缺失孔保持空白。Excel修改后必须重新导入，不声称已生成工程会自动联动。详见 [Prism导入与验证](excel_prism.md#prism导入与验证)。

DAPI自动处理字段及方法批准契约见 [DAPI LoG](dapi_log.md)。旧DAPI逐图审阅记录不能代替新的LoG实例标签，也不要求新的逐图人工验收。
