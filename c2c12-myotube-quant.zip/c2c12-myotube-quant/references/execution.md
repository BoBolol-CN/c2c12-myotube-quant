# 执行方式

按当前环境发现可用程序，优先本机已有的ImageJ与Python。以下`<skill>`、`<run>`、`<python>`、`<node>`均替换为绝对路径；在PowerShell中用`&`运行带空格路径。

1. 用户确认实验设计后准备manifest；运行 `python <skill>/scripts/validate_manifest.py --manifest <run>/input.json`。
2. `python <skill>/scripts/select_pilot.py --manifest <run>/input.json --out <run>/pilot.json`。
3. `python <skill>/scripts/run_batch.py --manifest <run>/input.json --out <run>/preview-round1 --mode preview --pilot <run>/pilot.json --myhc-multiplier 当前候选值 --dapi-multiplier 当前候选值`。不做指标统计。调整参数用新的输出目录、同一pilot。
4. 两通道验收后保存review.json，运行 `python <skill>/scripts/run_batch.py --manifest <run>/input.json --out <run>/measure --mode measure --pilot <run>/pilot.json --review-record <run>/review.json --myhc-multiplier 已确认值 --dapi-multiplier 已确认值`。可用`--imagej`指定原生ImageJ-win64.exe。
5. 已有本批批准的掩膜时可用 `--accepted-masks <run>/accepted_masks.json`，不重新分割。顶层必须含batch_id、manifest_sha256、myhc_multiplier、dapi_multiplier，与本批验收记录一致；fields为 `[{"group":"组A","field":"F01","myhc_mask":"绝对路径","dapi_mask":"绝对路径","myhc_mask_sha256":"实际SHA256","dapi_mask_sha256":"实际SHA256"}]`。所有配对必须覆盖输入manifest，来源需绑定本批验收，不能仅因有文件就当作已批准。
6. 输出保留每视野掩膜、原生宏/日志（新分割时）、summary/objects/nuclei/provenance JSON、全批batch_measurements.json。数字与掩膜检查失败时中止Excel输出，修正原因后在新目录重跑。首次执行可回归一对已批准原图，确认新包装器与已认可掩膜逐像素一致。

## Excel 导出

遵循可用的spreadsheets技能：先load_workspace_dependencies定位随应用提供的Node与`@oai/artifact-tool`，不使用项目自装依赖或openpyxl作者库。把skill中的`export_excel.mjs`复制到当前批次的可写`<run>/workbook_code/`；在该目录建立node_modules链接/Windows junction，指向已发现的运行库node_modules，不修改运行库本身。不要把固定电脑的node_modules链接打包到skill。

在第一次Excel创建/编辑执行前，按表格技能要求运行一次mark_artifact_operation_started.mjs。之后：

`node <run>/workbook_code/export_excel.mjs --input <run>/measure/batch_measurements.json --output <run>/C2C12_定量与Prism.xlsx`

脚本导出一次.xlsx，生成局部预览及公式核验JSON。查看预览，检查中文指标/单位/孔标签清楚，检查保存的xlsx中无冻结/拆分pane、公式缓存与独立均值一致。修改Excel展示时读取已有批量数据，不重新跑ImageJ。

运行ImageJ使用原生启动器。旧版不支持Unicode参数时只经ASCII临时目录传参，保留原图不变；如系统沙箱影响启动或运行库读取，使用已有授权范围内的执行方式。像素原始值和MyHC掩膜不得因显示提亮或Excel排版改变。
